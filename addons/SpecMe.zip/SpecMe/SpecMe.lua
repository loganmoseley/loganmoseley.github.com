SpecMeSettings = {
	["updateRate"] = 0.25,
	["spec_table"] = {},
	["spec_table_len"] = 0,
	["num_table"] = {},
	["doLearnNow"] = 0,
	["atNum"] = 1,
	["atTab"] = 1,
	["atTalent"] = 1,
	["tabName"] = "",
}

function SpecMe_OnSlash(in_str)
	SMPrint("|cffffff00|-----SpecMe feedback-----\n")
	
	if( type(in_str) == 'string' ) then
	
		in_str = strtrim(in_str)
		directive = ""
		command = ""
		spacePos = strfind(in_str, "%s")
		
		if( spacePos ) then
			directive = strtrim(strsub(in_str, 1, spacePos-1))
			command = strtrim(strsub(in_str, spacePos+1))
		
			if( directive == 'spec' ) then
				SpecMeSettings.num_table = ParseSpec(command)
				ActivateSpec()
			elseif( directive == 'save' or directive == 'add' ) then
				SaveSpec(command)
			elseif( directive == 'del' or directive == 'delete' or directive == 'rm' or directive == 'remove') then
				DelSpec(command)
			elseif( directive == 'learn' or directive == 'load') then
				LearnSpec(command)
				
			elseif( directive == 'cancel' or directive == 'stop' ) then
				DeactivateSpec()
			elseif( directive == 'pause' ) then
				PauseSpec()
			elseif( directive == 'resume' ) then
				ResumeSpec()
			elseif( directive == 'print' or directive == 'show' ) then
				PrintSaved(command)
			else
				SMPrint("Unknown directive.")
			end
			
		elseif( in_str == 'cancel' or in_str == 'stop' ) then
			DeactivateSpec()
		elseif( in_str == 'pause' ) then
			PauseSpec()
		elseif( in_str == 'resume' ) then
			ResumeSpec()
		elseif( in_str == 'print' or in_str == 'show' ) then
			PrintSaved()
		elseif( in_str == '' ) then
			SMUsage()
		else
			SMPrint("Invalid SpecMe input.")
		end
	else
	end
end

function SaveSpec(command)
	local spacePos = strfind(command, "%s")
	if( spacePos ) then
		name = strtrim(strsub(command, 1, spacePos-1))
		spec = strtrim(strsub(command, spacePos+1))
		short_distro = ""
		
		sub_spec = spec
		for i=1,GetNumTalentTabs() do
			--SMPrint("Tab #" .. i)
			running_total = 0
			traversed = 0
			for j=1,GetNumTalents(i) do
				running_total = running_total + tonumber(strsub(sub_spec, j, j))
				--SMPrint("j: " .. j .. "  |  rt: " .. running_total)
				traversed = j
			end
			sub_spec = strsub(sub_spec, traversed+1)
			short_distro = short_distro .. "/" .. running_total
		end
		short_distro = strsub(short_distro, 2)
		
		SpecMeSettings.spec_table_len = SpecMeSettings.spec_table_len + 1
		SpecMeSettings.spec_table[SpecMeSettings.spec_table_len] = {name, spec, short_distro}
		SMPrint("|cffffff00| |cffffffff[|c4422aaff" .. SpecMeSettings.spec_table_len .. "|cffffffff] " 
					.. SpecMeSettings.spec_table[SpecMeSettings.spec_table_len][1] 
					.. " (" .. SpecMeSettings.spec_table[SpecMeSettings.spec_table_len][3] .. ") |cffff6103saved|cffffffff.")
					
		SMPrint("|cffffff00| Currently saved specs:")
		PrintSaved()
	end
end

function DelSpec(index)
	index = tonumber(index)
	if( SpecMeSettings.spec_table[index] ) then
	
		SMPrint("[" .. index .. "] " 
					.. SpecMeSettings.spec_table[index][1] 
					.. " (" .. SpecMeSettings.spec_table[index][3] .. ") removed.")
					
		for i=index,SpecMeSettings.spec_table_len do
			SpecMeSettings.spec_table[i] = SpecMeSettings.spec_table[i+1]
		end
		SpecMeSettings.spec_table[SpecMeSettings.spec_table_len] = nil
		SpecMeSettings.spec_table_len = SpecMeSettings.spec_table_len - 1
		SpecMeSettings.num_table = {}
		
		SMPrint("|cffffff00| Currently saved specs:")
		PrintSaved()
	end
end

function LearnSpec(index)
	index = tonumber(index)
	
	SMPrint("|cffffff00| |cffffffffYou have chosen to learn [|c4422aaff" .. index .. "|cffffffff] " 
		.. SpecMeSettings.spec_table[index][1]
		.. " (" .. SpecMeSettings.spec_table[index][3] .. ").")
	
	if( SpecMeSettings.spec_table[index] ) then
		SpecMeSettings.num_table = ParseSpec(SpecMeSettings.spec_table[index][2])
		ActivateSpec()
	else
		SMPrint("|c4422aaffINDEX |cffffffff[" .. index .. "] spec not found.")
	end
end

function PrintSaved(index)
	if( index ) then
		index = tonumber(index)
		if( SpecMeSettings.spec_table[index] ) then
			SMPrint("|cffffff00| |cffffffff[|c4422aaff" .. index .. "|cffffffff] " 
						.. SpecMeSettings.spec_table[index][1] 
						.. " (" .. SpecMeSettings.spec_table[index][3] .. "):\n")
			SMPrint("|cffffff00| |cffffffff" .. SpecMeSettings.spec_table[index][2])
		else
			SMPrint("|cffffff00| |c4422aaffINDEX |cffffffff[|c4422aaff" .. index .. "|cffffffff] spec not found.")
		end
	else
		for i=1,SpecMeSettings.spec_table_len do
			SMPrint("|cffffff00| |cffffffff[|c4422aaff" .. i .. "|cffffffff] " 
					.. SpecMeSettings.spec_table[i][1]
					.. " (" .. SpecMeSettings.spec_table[i][3] .. ")")
		end
	end
end
				
function ParseSpec(spec)
	temp_num_table = {}
	
	for i=1,strlen(spec) do
		str_to_num = tonumber(string.sub(spec, i, i))
		if( type(str_to_num) == 'number' ) then
			temp_num_table[i] = str_to_num
		end
	end
	
	return temp_num_table
end

function ActivateSpec()
	SpecMeSettings.doLearnNow = 1
	SpecMeSettings.atNum = 1
	SpecMeSettings.atTab = 1
	SpecMeSettings.atTalent = 1
	
	local tabName, tex, spent, backg = GetTalentTabInfo(SpecMeSettings.atTab)
	SMPrint("|cffffff00| |cffffffffSpecMe is beginning talent point distribution, please wait...\n"
			.."|cffffff00| |cffffffffBeginning " .. tabName .. ".")
end

function DeactivateSpec()
	SpecMeSettings.doLearnNow = 0
	SpecMeSettings.num_table = {}
	SMPrint("|cffffff00| |cffffffffCancelling distribution.")
end

function PauseSpec()
	SpecMeSettings.doLearnNow = 0
	SMPrint("|cffffff00| |cffffffffPausing distribution,  '/specme resume' to resume.")
end

function ResumeSpec()
	SpecMeSettings.doLearnNow = 1
	SMPrint("|cffffff00| |cffffffffResuming distribution.")
end

function LearnNewTalent()
	if( SpecMeSettings.num_table[SpecMeSettings.atNum] ~= nil ) then
		local nameTalent, iconPath, tier, column, currentRank, maxRank, isExceptional, meetsPrereq = GetTalentInfo(SpecMeSettings.atTab, SpecMeSettings.atTalent)
		
		if( currentRank < SpecMeSettings.num_table[SpecMeSettings.atNum] ) then
			LearnTalent(SpecMeSettings.atTab,SpecMeSettings.atTalent)
		end
		
		if( (currentRank >= maxRank) or (currentRank >= SpecMeSettings.num_table[SpecMeSettings.atNum]) ) then
			SpecMeSettings.atTalent = SpecMeSettings.atTalent + 1
			SpecMeSettings.atNum = SpecMeSettings.atNum + 1
		end
		if( SpecMeSettings.atTalent > GetNumTalents(SpecMeSettings.atTab) ) then
			SpecMeSettings.atTab = SpecMeSettings.atTab + 1
			SpecMeSettings.atTalent = 1
			if( SpecMeSettings.atTab < 4 ) then
				local tabName, tex, spent, backg = GetTalentTabInfo(SpecMeSettings.atTab)
				if( tabName ) then
					SMPrint("|cffffff00| |cffffffffBeginning " .. tabName .. ".")
				end
			end
		end
	else
		SpecMeSettings.doLearnNow = 0
		SpecMeSettings.num_table = {}
	
		SMPrint("|cffffff00| |cffffffffTalent point distribution complete.\n"
			.. "|cffffff00| |cffffffffDon't forget to buy your new spells.")
	end
	
end

function SMUsage()
	SMPrint("|cffffff00| |cffffffffUsage: /specme |cffff6103spec |c00ff00ffPOINTS\n"
				.."|cffffff00|                            |cffff6103save |c0000ff66NAME |c00ff00ffPOINTS\n"
				.."|cffffff00|                            |cffff6103delete |c4422aaffINDEX\n"
				.."|cffffff00|                            |cffff6103learn |c4422aaffINDEX\n"
				.."|cffffff00|                            |cffff6103cancel|cffffffff, |cffff6103pause|cffffffff, or |cffff6103resume |cffffffffcurrent distro\n"
				.."|cffffff00|                            |cffff6103(print, show) [|c4422aaffINDEX|cffff6103]\n"
				.."|cffffff00| |c00ff00ffPOINTS |cffffffffof spec (from worldofwarcraft.com)\n"
				.."|cffffff00| |c0000ff66NAME |cffffffffof that spec\n"
				.."|cffffff00| |cffffffff[|c4422aaffINDEX|cffffffff] of target spec, as shown in '/specme show'")
end

function SMPrint(str)
	DEFAULT_CHAT_FRAME:AddMessage(str)
end

function HiddenSpecMe_OnLoad()
	this:RegisterEvent("CHARACTER_POINTS_CHANGED");
	this:RegisterEvent("ADDON_LOADED");
	SLASH_SPECME1 = "/specme";
	SLASH_SPECME2 = "/speccme";
	SLASH_SPECME3 = "/sm";
	SlashCmdList["SPECME"] = SpecMe_OnSlash;
	TimeSinceLastUpdate = 0
end

function HiddenSpecMe_OnEvent(event)
	if (event == "CHARACTER_POINTS_CHANGED") then
		if( arg1 >= 0 ) then
			SpecMeSettings.doLearnNow = 0
			SpecMeSettings.num_table = {}
		end
	end
	if (event == "ADDON_LOADED" and arg1 == "SpecMe") then
		SMPrint("|cffffff00| |cffffffffSpecMe loaded. Usage: '/specme'.");
	end
end

function HiddenSpecMe_OnUpdate(arg1)
	if( SpecMeSettings.doLearnNow == 1 ) then
		TimeSinceLastUpdate = TimeSinceLastUpdate + arg1
		if( TimeSinceLastUpdate > SpecMeSettings.updateRate ) then
			TimeSinceLastUpdate = 0
			LearnNewTalent()
		end
	end
end
