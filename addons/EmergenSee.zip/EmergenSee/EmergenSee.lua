EmergenSeeUpdateRate = 0.05;
EmergenSeeSettings = {
	["Enabled"] = 1,
	["ShowBG"] = 1,
	["ShowHP"] = 1,
	["ShowHPp"] = 1,
	["HPPercent"] = 50,
	["HPSize"] = 48,
	["ShowMP"] = 1,
	["ShowMPp"] = 1,
	["MPPercent"] = 50,
	["MPSize"] = 32,
	["Lock"] = nil,
	["ItemToUse"] = "Hearthstone",
}

function EmergenSeeEnable()
	if (EmergenSeeSettings.Enabled == nil) then
		EmergenSeeFrame:Hide();
	else
		EmergenSeeFrame:Show();
	end
end

function EmergenSee_OnSlash()
	if EmergenSeeOptionsFrame:IsShown() then
		EmergenSeeOptionsFrame:Hide();
	else
		EmergenSeeOptionsFrame:Show();
	end
end

--------------------------------------------------------------------------------------------------------------
--Main Display Window
--------------------------------------------------------------------------------------------------------------
function EmergenSee_OnMouseUp(arg1)
	EmergenSeeFrame:StopMovingOrSizing();
end

function EmergenSee_OnMouseDown(arg1)
	if (EmergenSeeSettings.Lock == nil) then
		if (IsShiftKeyDown()) then
			if(arg1 == "LeftButton") then
				EmergenSeeFrame:StartSizing("TOP");
			elseif(arg1 == "RightButton") then
				EmergenSeeFrame:StartSizing("BOTTOM");
			else
				if (DEFAULT_CHAT_FRAME) then
					DEFAULT_CHAT_FRAME:AddMessage("arg1 returned: "..arg1);
				end
			end
		elseif (IsControlKeyDown()) then
			if(arg1 == "LeftButton") then
				EmergenSeeFrame:StartSizing("LEFT");
			elseif(arg1 == "RightButton") then
				EmergenSeeFrame:StartSizing("RIGHT");
			else
				if (DEFAULT_CHAT_FRAME) then
					DEFAULT_CHAT_FRAME:AddMessage("arg1 returned: "..arg1);
				end
			end
		else
			EmergenSeeFrame:StartMoving();
		end
	end
end

--------------------------------------------------------------------------------------------------------------
--Options Window
--------------------------------------------------------------------------------------------------------------
function EmergenSeeOptionsFrame_OnShow()
	getglobal("EmergenSeeEnabledButton"):SetChecked(EmergenSeeSettings.Enabled);
	getglobal("EmergenSeeShowBGButton"):SetChecked(EmergenSeeSettings.ShowBG);
	getglobal("EmergenSeeShowHPButton"):SetChecked(EmergenSeeSettings.ShowHP);
	getglobal("EmergenSeeShowHPpButton"):SetChecked(EmergenSeeSettings.ShowHPp);
	getglobal("EmergenSeeShowHPPercentSlider"):SetValue(EmergenSeeSettings.HPPercent);
	getglobal("EmergenSeeShowHPSizeSlider"):SetValue(EmergenSeeSettings.HPSize);
	getglobal("EmergenSeeShowMPButton"):SetChecked(EmergenSeeSettings.ShowMP);
	getglobal("EmergenSeeShowMPpButton"):SetChecked(EmergenSeeSettings.ShowMPp);
	getglobal("EmergenSeeShowMPPercentSlider"):SetValue(EmergenSeeSettings.MPPercent);
	getglobal("EmergenSeeShowMPSizeSlider"):SetValue(EmergenSeeSettings.MPSize);
	getglobal("EmergenSeeHPClickEditBox"):SetText(EmergenSeeSettings.ItemToUse);
	getglobal("EmergenSeeLockButton"):SetChecked(EmergenSeeSettings.Lock);
end

function EmergenSeeOptionsFrame_OnLoad()
	this:RegisterForDrag("LeftButton");
	EmergenSeeOptionsFrameTitle:SetText("Options");
	EmergenSeeHPClickEditBoxText:SetText("Item to use when clicked:")
	EmergenSeeSettings.HPSize = EmergenSeeSettings.HPSize
	EmergenSeeSettings.MPSize = EmergenSeeSettings.MPSize
end

function EmergenSeeOptionsFrame_OnMouseDown()
	if (EmergenSeeSettings.Lock == nil) then
		this:StartMoving();
	end
end

function EmergenSeeOptionsFrame_OnMouseUp()
	this:StopMovingOrSizing();
end

--Checkboxes', sliders' behaviour
function EmergenSeeOptionsFrame_OnClick()
	if(this:GetName() == ("EmergenSeeEnabledButton")) then
		EmergenSeeSettings.Enabled = this:GetChecked();
		EmergenSeeEnable();
	elseif(this:GetName() == ("EmergenSeeShowBGButton")) then
		EmergenSeeSettings.ShowBG = this:GetChecked();
		if (EmergenSeeSettings.ShowBG == nil) then
			EmergenSeeFrame:SetBackdropBorderColor(BGborder_red, BGborder_green, BGborder_blue, 0);
			EmergenSeeFrame:SetBackdropColor(BGred, BGgreen, BGblue, 0);
		else
			EmergenSeeFrame:SetBackdropBorderColor(BGborder_red, BGborder_green, BGborder_blue, BGborder_alpha);
			EmergenSeeFrame:SetBackdropColor(BGred, BGgreen, BGblue, BGalpha);
		end
	elseif(this:GetName() == ("EmergenSeeShowHPButton")) then
		EmergenSeeSettings.ShowHP = this:GetChecked();
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowHPpButton")) then
		EmergenSeeSettings.ShowHPp = this:GetChecked();
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowHPPercentSlider")) then
		EmergenSeeSettings.HPPercent = this:GetValue();
		getglobal(this:GetName().."Text"):SetText("HP Percentage (" .. EmergenSeeSettings.HPPercent .. "%)");
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowHPSizeSlider")) then
		EmergenSeeSettings.HPSize = this:GetValue();
		getglobal(this:GetName().."Text"):SetText("HP Text Size (" .. EmergenSeeSettings.HPSize .. ")");
		EmergenSeeHPFrameText:SetFont(HPorig_font, EmergenSeeSettings.HPSize, HPorig_flags);
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowMPButton")) then
		EmergenSeeSettings.ShowMP = this:GetChecked();
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowMPpButton")) then
		EmergenSeeSettings.ShowMPp = this:GetChecked();
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowMPPercentSlider")) then
		EmergenSeeSettings.MPPercent = this:GetValue();
		getglobal(this:GetName().."Text"):SetText("MP Percentage (" .. EmergenSeeSettings.MPPercent .. "%)");
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeShowMPSizeSlider")) then
		EmergenSeeSettings.MPSize = this:GetValue();
		getglobal(this:GetName().."Text"):SetText("MP Text Size (" .. EmergenSeeSettings.MPSize .. ")");
		EmergenSeeMPFrameText:SetFont(MPorig_font, EmergenSeeSettings.MPSize, MPorig_flags);
		UpdateText();
	elseif(this:GetName() == ("EmergenSeeLockButton")) then
		EmergenSeeSettings.Lock = this:GetChecked();
		if (EmergenSeeSettings.Lock == 1) then
			EmergenSeeCast:Show()
		else
			EmergenSeeCast:Hide()
		end
	end
end

--Checkboxes', sliders' properties
function EmergenSeeEnabledButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Enable EmergenSee");
end
function EmergenSeeShowBGButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Show background");
end
function EmergenSeeShowHPButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Show HP");
end
function EmergenSeeShowHPpButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Show (HP%)");
end
function EmergenSeeShowHPPercentSlider_OnLoad()
	getglobal(this:GetName().."Text"):SetText("HP Percentage (" .. EmergenSeeSettings.HPPercent .. "%)");
	getglobal(this:GetName().."Low"):SetText("0");
	getglobal(this:GetName().."High"):SetText("100");
	this:SetMinMaxValues(0,100);
	this:SetValueStep(5);
end
function EmergenSeeShowHPSizeSlider_OnLoad()
	getglobal(this:GetName().."Text"):SetText("HP Size (" .. EmergenSeeSettings.HPSize .. ")");
	getglobal(this:GetName().."Low"):SetText("8");
	getglobal(this:GetName().."High"):SetText("36");
	this:SetMinMaxValues(8,36);
	this:SetValueStep(4);
end
function EmergenSeeShowMPButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Show MP");
end
function EmergenSeeShowMPpButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Show (MP%)");
end
function EmergenSeeShowMPPercentSlider_OnLoad()
	getglobal(this:GetName().."Text"):SetText("MP Percentage (" .. EmergenSeeSettings.MPPercent .. "%)");
	getglobal(this:GetName().."Low"):SetText("0");
	getglobal(this:GetName().."High"):SetText("100");
	this:SetMinMaxValues(0,100);
	this:SetValueStep(5);
end
function EmergenSeeShowMPSizeSlider_OnLoad()
	getglobal(this:GetName().."Text"):SetText("MP Percentage (" .. EmergenSeeSettings.MPSize .. ")");
	getglobal(this:GetName().."Low"):SetText("8");
	getglobal(this:GetName().."High"):SetText("36	");
	this:SetMinMaxValues(8,36);
	this:SetValueStep(4);
end
function EmergenSeeLockButton_OnLoad()
	getglobal(this:GetName().."Text"):SetText("Lock Frames");
end

--------------------------------------------------------------------------------------------------------------
--Hidden EmergenSee
--------------------------------------------------------------------------------------------------------------
function UpdateText()
	EmCHPText = "";
	EmCMPText = "";
	show = 0;
	
	if (EmergenSeeSettings.ShowHP == 1) then
		playerhp = UnitHealth("player");
		playerhpp = floor(playerhp/UnitHealthMax("player")*100);
		if (playerhpp <= EmergenSeeSettings.HPPercent) then
			EmCHPText = "|c0000ff00" .. UnitMana("player");
			if (EmergenSeeSettings.ShowHPp == 1) then
				EmCHPText = EmCHPText .. " (" .. playerhpp .. "%)";
			end
			show = 1;
		else
			EmCHPText = EmCHPText .. " ";
		end
	elseif (EmergenSeeSettings.ShowHPp == 1) then
		playerhp = UnitHealth("player");
		playerhpp = floor(playerhp/UnitHealthMax("player")*100);
		if (playerhpp <= EmergenSeeSettings.HPPercent) then
			EmCHPText = "|c0000ff00" .. playerhpp .. "%";
			show = 1;
		end
	end
	--if (EmergenSeeSettings.ShowHP == 1 and EmergenSeeSettings.ShowMP ==1) then
	--		EmCHPText = EmCHPText .. "\n";
	--end
	if (EmergenSeeSettings.ShowMP == 1) then
		playermp = UnitMana("player");
		playermpp = floor(playermp/UnitManaMax("player")*100);
		if (playermpp <= EmergenSeeSettings.MPPercent) then
			EmCMPText = "|c000088ff" .. UnitMana("player") .. " / " .. UnitManaMax("player") .. "\n-" .. (UnitManaMax("player")-playermp);
			if (EmergenSeeSettings.ShowMPp == 1) then
				EmCMPText = EmCMPText .. " (" .. playermpp .. "%)";
			end
			show = 1;
		else
			EmCMPText = EmCMPText .. " ";
		end
	elseif (EmergenSeeSettings.ShowMPp == 1) then
		playermp = UnitMana("player");
		playermpp = floor(playermp/UnitManaMax("player")*100);
		if (playermpp <= EmergenSeeSettings.MPPercent) then
			EmCMPText = "|c000088ff" .. playermpp .. "%";
			show = 1;
		end
	end
	
	if (show == 0) then
		EmergenSeeFrame:Hide();
	else
		EmergenSeeFrame:Show();
		EmergenSeeHPFrameText:SetText(EmCHPText);
		EmergenSeeMPFrameText:SetText(EmCMPText);
	end
end

function HiddenEmergenSee_OnLoad()
	this:RegisterEvent("VARIABLES_LOADED");
	this:RegisterEvent("UNIT_MANA");
	this:RegisterEvent("UNIT_HEALTH");
	SLASH_EMERGENSEE1 = "/emergensee";
	SLASH_EMERGENSEE2 = "/emsee";
	SLASH_EMERGENSEE3 = "/emc";
	SlashCmdList["EMERGENSEE"] = EmergenSee_OnSlash;
	EmCHPText = "";
	EmCMPText = "";
	HPorig_font, HPorig_size, HPorig_flags = EmergenSeeHPFrameText:GetFont()
	MPorig_font, MPorig_size, MPorig_flags = EmergenSeeMPFrameText:GetFont()
	BGborder_red, BGborder_green, BGborder_blue, BGborder_alpha = EmergenSeeFrame:GetBackdropBorderColor(r, g, b, a)
	BGred, BGgreen, BGblue, BGalpha = EmergenSeeFrame:GetBackdropColor(r, g, b, a)
	
	UpdateText();
end

function HiddenEmergenSee_OnEvent(event)
	if (event == "VARIABLES_LOADED") then
		EmergenSeeOptionsFrame_OnShow();
		if (EmergenSeeSettings.Lock == 1) then
			EmergenSeeCast:Show()
		else
			EmergenSeeCast:Hide()
		end
		ChatFrame1:AddMessage("EmergenSee loaded. Usage: '/emergensee', '/emsee', '/emc'.");
		ChatFrame1:AddMessage("     Shift / Ctrl drag the EmergenSee box to resize.");
	elseif (EmergenSeeSettings.Enabled == 1) then
		if ((event == "UNIT_MANA" or event == "UNIT_HEALTH") and arg1 == "player") then
			UpdateText();
		end
		if (EmergenSeeSettings.ShowBG == nil) then
			EmergenSeeFrame:SetBackdropBorderColor(BGborder_red, BGborder_green, BGborder_blue, 0);
			EmergenSeeFrame:SetBackdropColor(BGred, BGgreen, BGblue, 0);
		else
			EmergenSeeFrame:SetBackdropBorderColor(BGborder_red, BGborder_green, BGborder_blue, BGborder_alpha);
			EmergenSeeFrame:SetBackdropColor(BGred, BGgreen, BGblue, BGalpha);
		end
	else
		EmergenSeeFrame:Hide();
	end
end
