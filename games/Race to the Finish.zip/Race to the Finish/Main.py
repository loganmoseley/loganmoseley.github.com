import direct.directbase.DirectStart				# starts Panda
from pandac.PandaModules import *				# basic Panda modules
from direct.showbase.DirectObject import DirectObject	# event handling
from direct.actor.Actor import Actor				# animated models
from direct.interval.IntervalGlobal import *			# compound intervals
from direct.task import Task
from direct.gui.DirectGui import *					# 2d stuff
from direct.gui.OnscreenText import OnscreenText		# 2d text
from direct.gui.OnscreenImage import OnscreenImage	# 2d images
from pandac.PandaModules import TransparencyAttrib 	# 2d image transaparency
import sys
import math
import random

# -----------------
# GLOBALS
# cannot change?
# -----------------
CARMAXSPEED = 15
CARACCEL = 0.25
CARTURNMAXSPEED = 15
CARTURNACCEL = 0.25
WAYPOINTPROX = 25

class World(DirectObject):
	def __init__(self):
		base.disableMouse()
		
		globalClock.getFrameTime()
		
		self.laps_text = OnscreenText(text="Laps Completed: ", style=3, fg=(1,1,1,1), pos=(-1.3, 0.9), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.prev_lap_text = OnscreenText(text="Previous Lap Time: ", style=3, fg=(1,1,1,1), pos=(-1.3, 0.8), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.best_lap_text = OnscreenText(text="Best Lap: ", style=3, fg=(1,1,1,1), pos=(-1.3, 0.7), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.current_lap_text = OnscreenText(text="Best Lap: ", style=3, fg=(1,1,1,1), pos=(-1.3, 0.6), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.total_time_text = OnscreenText(text="Timer: ", style=3, fg=(1,1,1,1), pos=(-1.3, 0.5), align=TextNode.ALeft, scale = .10, mayChange = 1)
		
		self.velocity_text = OnscreenText(text="Velocity: ", style=3, fg=(1,1,1,1), pos=(-1.3, -.6), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.turning_text = OnscreenText(text="Turning: ", style=3, fg=(1,1,1,1), pos=(-1.3, -.7), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.panda_x = OnscreenText(text="X: ", style=3, fg=(1,1,1,1), pos=(-1.3, -.8), align=TextNode.ALeft, scale = .10, mayChange = 1)
		self.panda_y = OnscreenText(text="Y: ", style=3, fg=(1,1,1,1), pos=(-1.3, -.9), align=TextNode.ALeft, scale = .10, mayChange = 1)
		
		self.minimap = OnscreenImage(image = 'hud_map_track.png', pos = (1.08, 0, .75), scale = .25)
		self.minimap.setTransparency(TransparencyAttrib.MAlpha)
		self.minimap_car = OnscreenImage(image = 'hud_map_car.png', pos = (.88, 0, .77), scale = .025)
		self.minimap_car.setTransparency(TransparencyAttrib.MAlpha)
		
		self.speedometer = OnscreenImage(image = 'hud_speed_slow.png', pos = (1.05, -1, -.87), scale = (0.25,1,0.10))
		self.speedo_text = OnscreenText(text="0", style=3, fg=(1,1,1,1), pos=(1.08, -0.94), align=TextNode.ALeft, scale = .07, mayChange = 1)
		
		self.WAYPOINTS = [(-5,4),(-5,354),(50000,50000)]
		self.LAPSDONE = 0
		
		self.isSlow = False
		
		self.loadModels()
		self.setupLighting()
		
		self.loadSounds()
		SoundInterval(self.music).loop()
		
		self.setupCollisions()
		self.time_turning = 1							# helps handle car turning
		self.accel_frame = 1.05						# helps handle car acceleration, must be >1
		self.moving_forward = 1						# car moving forward or backward
		
		self.is_near_waypoint = 0						# is the car near the waypoint
		self.next_waypoint = 0							# next waypoint to be checked against
		
		self.prev_lap = 0								# previous lap time
		self.current_lap = 0							# current lap time
		self.best_lap = 0								# best lap time
		self.total_completed = 0						# sum of previous laps' time
		
		# setup key controls
		self.up = 0									# 0: up;	1: down
		self.down = 0
		self.left = 0
		self.right = 0
		self.dist = 0
		
		self.accept("escape", sys.exit)
		self.accept("arrow_up", self.setWalk, [1,1])			# first argument is up/down
		self.accept("arrow_up-up", self.setWalk, [1,0])		# second argument is key up/down
		self.accept("arrow_down", self.setWalk, [0,1])			#   -up    is key up
		self.accept("arrow_down-up", self.setWalk, [0,0])
		self.accept("arrow_left", self.turn, [-1,1])			# first argument is left/right
		self.accept("arrow_left-up", self.turn, [-1,0])		# second argument is key up/down
		self.accept("arrow_right", self.turn, [1,1])
		self.accept("arrow_right-up", self.turn, [1,0])
		
		taskMgr.add(self.walk, 'walk')
	
	def turn(self, dir, act):							# dir: left/right;	act: key up/down
		if dir == -1:									# if turn left
			self.left = act
		else:
			self.right = act
		
		
	def walk(self, task):							
#		pandaWalk = Sequence()

		# save the current position
		startpos = self.handle.getPos()		
		
		# -------------------
		# ACCELERATION
		# -------------------
		if self.up == 1:										# if up key is down
			self.dist = self.dist+CARACCEL
		elif self.down == 1:									# if down key is down
			self.dist = self.dist-CARACCEL
		elif self.dist > 0:										# if decelerating going forward
			self.dist = self.dist-CARACCEL
		elif self.dist < 0:										# if decelerating going backward
			self.dist = self.dist+CARACCEL
		
		maxspeed = CARMAXSPEED
		
		if self.isSlow:
			maxspeed = maxspeed / 2
		
		if self.dist > maxspeed:								# regulates max speed
			self.dist = maxspeed
		elif self.dist < -maxspeed:
			self.dist = -maxspeed


		angle = self.handle.getH()*math.pi/180.0
		self.handle_velocity[0] = self.dist*math.sin(angle)*.25				# (*.25) to slow the car, it was going too fast
		self.handle_velocity[1] = self.dist*-math.cos(angle)*.25
		
		# ------------
		# TURNING
		# ------------
		if self.left == 1:										# if left key is down
			self.time_turning += CARTURNACCEL
			if self.time_turning > CARTURNMAXSPEED:				# regulates turning speed
				self.time_turning = CARTURNMAXSPEED
			self.handle.setHpr( self.handle.getH()+self.time_turning, self.handle.getP(), self.handle.getR())
			if self.dist > 0:
				self.panda.setPosHpr(-0.2*(self.dist/15), self.panda.getY(), 0.2*(self.dist/15),
								self.panda.getH(), self.dist, self.panda.getR())
			elif self.dist < 0:
				self.panda.setPosHpr(-0.2*(self.dist/15), self.panda.getY(), 0.2*(self.dist/15),
								self.panda.getH(), self.dist, self.panda.getR())
		elif self.right == 1:									# if right key is down
			self.time_turning += CARTURNACCEL
			if self.time_turning > CARTURNMAXSPEED:
				self.time_turning = CARTURNMAXSPEED
			self.handle.setHpr( self.handle.getH()-self.time_turning, 0, 0)
			if self.dist > 0:
				self.panda.setPosHpr(0.2*(self.dist/15), self.panda.getY(), 0.2*(self.dist/15),
								self.panda.getH(), -self.dist, self.panda.getR())
			elif self.dist < 0:
				self.panda.setPosHpr(0.2*(self.dist/15), self.panda.getY(), 0.2*(self.dist/15),
								self.panda.getH(), -self.dist, self.panda.getR())
		else:
			self.time_turning = 1
			self.panda.setPosHpr(0,0,0, self.panda.getH(), 0, self.panda.getR())
		
		# ----------------
		# ANIMATION
		# ----------------
		if self.dist != 0:
			self.handle.setPos(self.handle.getX()+self.handle_velocity[0], self.handle.getY()+self.handle_velocity[1], self.handle.getZ())
			Parallel(self.panda.actorInterval("forward", loop=1, duration=2.0)).start()
		else:
			Parallel(self.panda.actorInterval("idle", loop=1, duration=2.0)).start()
		
		
		
		frame_time = globalClock.getFrameTime()
		self.current_lap = frame_time-self.total_completed
		
		# -------------------------
		# WAYPOINTS & LAPS
		# -------------------------
		self.is_near_waypoint = self.isClose(self.handle.getX(), self.handle.getY(), self.WAYPOINTS)
		if self.is_near_waypoint:
			self.next_waypoint += 1
			if self.WAYPOINTS[self.next_waypoint][0] == 50000:
				self.next_waypoint = 0
				self.LAPSDONE += 1
				self.prev_lap = (math.floor( 100*self.current_lap ))/100
				self.total_completed = frame_time
				if self.LAPSDONE == 1:
					self.best_lap = self.prev_lap
				else:
					self.best_lap = min(self.best_lap, self.prev_lap)
		else:
			print "(" + str(self.WAYPOINTS[self.next_waypoint][0]) + "," + str(self.WAYPOINTS[self.next_waypoint][1]) + ")"
			
		# ------
		# HUD
		# ------
		self.laps_text.setText("Laps Completed: " + str( self.LAPSDONE ))
		self.prev_lap_text.setText("Previous Lap Time: " + str( self.prev_lap ))
		self.best_lap_text.setText("Best Lap: " + str( self.best_lap ))
		self.current_lap_text.setText("Current Lap: " + str( (math.floor( 100*self.current_lap ) )/100 ))
		self.total_time_text.setText("Total Time: " + str( (math.floor(100*frame_time))/100 ))
		
		self.velocity_text.setText("Velocity: " + str(self.dist))
		self.turning_text.setText("Turning: " + str(0.03*self.time_turning))
		self.panda_x.setText("X: " + str(self.handle.getX()))
		self.panda_y.setText("Y: " + str(self.handle.getY()))
		
		self.minimap_car.setPos(.88+self.handle.getX()/2500,0,.77+self.handle.getY()/2500)
		
		if( self.dist >= 10 or self.dist <= -10 ):
			self.speedometer.setImage('hud_speed_fast.png')
		elif self.dist == 0:
			self.speedometer.setImage('hud_speed_idle.png')
		else:
			self.speedometer.setImage('hud_speed_slow.png')
		#self.speedo_text.setText(str(self.dist))
		self.speedo_text.destroy()
		self.speedo_text = OnscreenText(text=str(self.dist), style=3, fg=(1,1,1,1), pos=(1.08, -0.94), align=TextNode.ALeft, scale = .07, mayChange = 1)
		
		
		
		#-------------------
		# GROUNDING
		#-------------------
		
		# check for collisions
		self.cTrav.traverse(render)
		
		# do the z adjustment
		entries = []
		for i in range(self.groundHandler.getNumEntries()):
			entry = self.groundHandler.getEntry(i)
			entries.append(entry)
		# sort the collision entries
		entries.sort(lambda x,y: cmp(y.getSurfacePoint(render).getZ(), x.getSurfacePoint(render).getZ()))
		
		#find the new z height
		if (len(entries)>1) and (entries[1].getIntoNode().getName() != "Car") and (abs(entries[1].getSurfacePoint(render).getZ() - self.handle.getZ()) < 20):
			self.handle.setZ(entries[1].getSurfacePoint(render).getZ())
		else:
			#print "%s %s" % (entries[1].getSurfacePoint(render).getZ(),  self.handle.getZ())
			self.handle.setPos(startpos)
	
		#-------------------
		# TRACK MASK
		#-------------------
	
		entries = []
		for i in range(self.trackHandler.getNumEntries()):
			entry = self.trackHandler.getEntry(i)
			entries.append(entry)
		
		entries.sort(lambda x,y: cmp(y.getSurfacePoint(render).getZ(), x.getSurfacePoint(render).getZ()))
		
		if len(entries) < 4:
			print "off the track!"
			self.isSlow = True
		else:
			self.isSlow = False
	
		return Task.cont
	
	
	def setWalk(self, dir, act):		
		if dir == 1:
			self.up = act
		else:
			self.down = act
			
	def isClose(self, x, y, waypoint_list):
		if( abs(x-waypoint_list[self.next_waypoint][0]) <= WAYPOINTPROX and abs(y-waypoint_list[self.next_waypoint][1]) <= WAYPOINTPROX ):
			return 1
		else:
			return 0
		
	def loadSounds(self):
		self.eatSound = loader.loadSfx("sounds/eatCrunch.wav")
		self.music = loader.loadMusic("sounds/BabyElephantWalk.MP3")
		
	def loadModels(self):
		
		# load the track
		self.environment = loader.loadModel("ground_art.mb.egg")
		self.environment.reparentTo(render)
		self.environment.setScale(25)
		self.environment.setPos(+490,-50,-102)
		
		self.track = loader.loadModel("groundmask.mb.egg")
		self.track.reparentTo(render)
		self.track.setScale(25)
		self.track.setPos(+490, -50, -150)
		#self.track.setFromCollideMask(Bitmask32.bit(2))
		
		
		self.handle = NodePath(PandaNode("Handle"))
		self.panda = Actor("car/car_idle.mb.egg", {"forward":"car/car_forward.mb.egg", "idle":"car/car_idle.mb.egg"})
		self.panda.reparentTo(self.handle)
		self.handle.reparentTo(render)
		self.panda.setScale(0.25)
		self.panda.setH(-90)
		

		self.handle_velocity = [0,0]
		self.handle.setH(180)
		
		
		camera.reparentTo(self.handle)
		camera.setPosHpr(0,25,10,-180,-10,0)
		
		
	def setupCollisions(self):
		self.cTrav = CollisionTraverser()
		
		#ground
		self.groundRay = CollisionRay()
		self.groundRay.setOrigin(0, 0, 1000)
		self.groundRay.setDirection(0,0, -1)
		
		self.groundCol = CollisionNode('groundRay')
		self.groundCol.addSolid(self.groundRay)
		
		self.groundColNP = self.handle.attachNewNode(self.groundCol)
		
		self.groundColNP.node().setFromCollideMask(BitMask32.bit(1))
		self.groundColNP.node().setIntoCollideMask(BitMask32.allOff())
		
		
		self.groundHandler = CollisionHandlerQueue()
		self.cTrav.addCollider(self.groundColNP, self.groundHandler)
		
		#show the collision rays
		self.groundColNP.show() 
		
		
		# setup track
		self.trackRay = CollisionRay()
		self.trackRay.setOrigin(0, 0, 0)
		self.trackRay.setDirection(0, 0, -1)
		
		self.trackCol = CollisionNode('trackRay')
		self.trackCol.addSolid(self.trackRay)
		self.trackCol.setFromCollideMask(BitMask32.allOn())
		self.trackCol.setIntoCollideMask(BitMask32.allOff())
		
		self.trackColNP = self.handle.attachNewNode(self.trackCol)
		self.trackHandler = CollisionHandlerQueue()
		
		#self.tcTrav = CollisionTraverser()
		self.cTrav.addCollider(self.trackColNP, self.trackHandler)
		
		#self.trackColNP.show()

		base.cTrav = self.cTrav				# makes Traverser, sets it to world default
		
		
		#setup handle
		bounds = self.handle.getChild(0).getBounds()
		center = bounds.getCenter()
		radius = bounds.getRadius()
		cSphere = CollisionSphere(center,radius)
		cNode = CollisionNode("Car")
		cNode.addSolid(cSphere)				# add collision sphere to collision node
		cNodePath = self.handle.attachNewNode(cNode)
		#cNodePath.setCollideMask(BitMask32.allOff())
#DON'T REMOVE		
		#cNodePath.show()

#DON'T REMOVE		
		#self.cTrav.showCollisions(render)
		#self.tcTrav.showCollisions(render)


	def setupLighting(self):
		dirLight = DirectionalLight('dirLight')
		dirLight.setColor(Vec4(0.6,0.6,0.6,1.0))
		dirLightNP = render.attachNewNode(dirLight)
		dirLightNP.setHpr(0.0,-26.0,0.0)
		render.setLight(dirLightNP)				# turn light on
#		render.clearLight(dirLightNP)				# turn light off

		ambientLight = AmbientLight('ambientLight')
		ambientLight.setColor(Vec4(0.25,0.25,0.25,1.0))
		ambientLightNP = render.attachNewNode(ambientLight)
		render.setLight(ambientLightNP)
		
	def cameraFollowTask(self, task):			# implicit self and task argument
		camera.lookAt(self.handle)
		return Task.cont



world=World()
run()
