****** BETA *** April 24, 2009 ******

Player.js

	Controls all player movement, input, sound, GUI, and animation.



Player lead programmer:		Logan Moseley

Player also developed by:	Andrew Dolce, Michael 'Z' Goddard, Kyle Okaly


"Faye's Shift"

	Programming:	Andrew Dolce, Michael 'Z' Goddard, Logan Moseley, Kyle Okaly

	Sound/Music:	Greg Lane, Kyle Okaly

	Art:		Robert Baldwin


*************************************

    Faye's Shift is a 2.5D platformer in which the player phases between the lava and
the ice phases in order to navigate past obstacles and progress through the world.  
The two phases have distinct personalities, including art and enemies.
    All art was done in Photoshop, matted onto planes in Maya, and each asset imported
as a single mesh into Unity.  Animations were done by separating each piece of the
character into limbs and IKs and animating like they were standard 3D meshes.

*************************************

To run, open "Faye's Shift.exe" or "Faye's Shift***.app".
Downloaded from http://rpi.edu/~mosell/

Keyboard Controls:
	A, Left Arrow:	Move left
	D, Right Arrow:	Move right
	Spacebar:	Jump
	Z:		Grab
	Left Shift:	Permanent Phase
	Left Ctrl:	Temporary Phase

Gameplay Notes:
	Lizards can be grabbed by jumping on their heads to stun and using Grab.
	Yeti can be grabbed by sneaking up behind them and using Grab.