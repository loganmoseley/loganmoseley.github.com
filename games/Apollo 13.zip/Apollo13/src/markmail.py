import smtplib


def markmailer(subject, message):
	fromaddr = "SpaceStalin@rpi.edu"
	toaddrs = "destem@rpi.edu"

	headers = "From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n" % (fromaddr, toaddrs, subject)
	text = message
	
	msg = headers + text
	
	server.set_debuglevel(0)
	server = smtplib.SMTP('mail.rpi.edu', 25)
	
	server.quit