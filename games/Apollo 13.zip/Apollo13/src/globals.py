FRAMESPERSECOND = 30

BULLETDELAY = 6
BULLETACCEL = 3
HOSTILE_BULLET_ACCEL= 1
GUIDED_MISSLE_SPEED = 8

MISSILEDELAY = 48
MISSILEACCEL = .3

BOMBDELAY = 300
BOMBACCEL = 0

PLAYERSHIPACCEL = 1

GAMEOVER = 0
GOTOSCREEN = "Title Screen"

# sound engine settings
SOUNDEFFECTSDIR = "../sound/effects/"
SOUNDMUSICDIR = "../sound/music/"
SOUNDMAXEFFECTS = 16		# not used (yet)
SOUNDEFFECTSVOLUME = 0.30 #0.30
SOUNDMUSICVOLUME = 0.90 #0.90
SOUNDMUSICFADETIME = 2000
# sound mixer settings
SOUNDFREQUENCY = 11025
SOUNDSAMPLESIZE = -16
SOUNDSTEREO = 1
SOUNDBUFFERSIZE = 1024

# the art directory
ARTDIR = "../art/"

# fonts
FONTSTEAK = "../fonts/STEAK.ttf"

SHIP_EXPLOSION_TIME = 32 #in frames

# speed of the background
STAGE_1_BACKGROUND_SPEED = 2
STAGE_2_BACKGROUND_SPEED = 5
STAGE_3_BACKGROUND_SPEED = 10

# stages, dont mess with this part unless you knowwhat you're doing
STAGE_1 = 1
STAGE_2 = 2
STAGE_3 = 3
STAGE_STALIN = 4

HOSTILE_DEAD = 0
HOSTILE_NORMAL = 1
HOSTILE_DYING = 2

PLAYER_DEAD = 0
PLAYER_NORMAL = 1
PLAYER_DYING = 2
PLAYER_REVIVING = 3

# ship settings
PLAYER_LIVES = 7
PLAYER_HP = 1

RAMMING_DAMAGE = 10
BULLET_DAMAGE = 1
MISSILE_DAMAGE = 3
EMP_FREEZE_TIME = 900

ZEP_HEALTH = 5
SAT_HEALTH = 3
MIG_HEALTH = 2
STALIN_HEALTH = 100
#frames to delay shooting...numbers less than like 30 will make this pretty much impossible.
ZEP_FIRE_DELAY = 50
SAT_FIRE_DELAY = 45
MIG_FIRE_DELAY = 30

SAT_BULLET_SPEED = 5
STALIN_BULLET_SPEED = 10
STALIN_MISSILE_SPEED = 7

HOSTILE_BULLET_DAMAGE = 1

#frames for random shooting...a random number between these 2 is added to the shot clock for hostiles
HOSTILE_COOLDOWN_RANDOM_BOTTOM = 0
HOSTILE_COOLDOWN_RANDOM_TOP = 30


DEBUG = False

