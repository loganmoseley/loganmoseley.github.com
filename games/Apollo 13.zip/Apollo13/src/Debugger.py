import pygame

# #Howto include this:
#	from Debugger Import *
#	debugger = RealDebugger(screen)
#	#before the screen.update call, run
#	debugger.show()

#debugger class:
#Use debugger.show() at the end of the render loop before the screen is blitted
#Use debugger.add(message, time) where message is the string to display and time is the number of seconds to display it (-1 = forever)

class RealDebugger:
	def __init__(self, screen):
		#init function
		self.debugList = []
		self.font = pygame.font.Font(None, 18)
		self.screen = screen
	
	def add(self, text, time):
		self.debugList.append([text, (time*60)])
		
	def show(self):
		#run through the debug text and remove old ones
		
		#item counter for display positions
		itemcount = 0
		
		for debugitem in self.debugList:
			debugitem[1] = debugitem[1] - 1
			if debugitem[1] == 0:
				self.debugList.remove(debugitem)
			else:
				temp = self.font.render(debugitem[0], 1, (255,0,0), (0,0,0))
				textpos = temp.get_rect()
				self.screen.blit(temp, pygame.Rect(0, (itemcount * 20) , 300, 200))
				itemcount = itemcount + 1

