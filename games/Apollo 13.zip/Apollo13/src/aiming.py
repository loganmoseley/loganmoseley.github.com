#I don't actually know the proper return statement for a Python Function, so I'm using 'return' for now.

import math

#Used exclusively in the aim function to correct the aiming quadrant.
def adjust_aim(x1, y1, x2, y2):
  a_x = (x2-x1)/math.fabs(x2-x1)
  #x2-x1 = shipx - shootx, negative if negative and positive if positive, divide by abs to get -1 or 1
  a_y = (y2-y1)/math.fabs(y2-y1)
  #Same as a_x, but for y
  a_x_y = [a_x, a_y]
  return a_x_y

#returns a float of radians used by the aim function. 
def getdirect(x1, y1, x2, y2):
  d_x = math.fabs(x1 - x2)
  d_y = math.fabs(y1 - y2)
  d_dir = math.atan2(d_y,d_x)
  return d_dir

#Given a shooter at x1, y1 and a target at x2, y2, fire a bullet at velocity v in that direction with offset angle. Returns the x and y velocities
def aim(x1, y1, x2, y2, v, offset = 0):
  r_dir = getdirect(x1,y1,x2,y2)
  r_dir += math.radians(offset)
  d_y = v*math.sin(r_dir)
  d_x = v*math.cos(r_dir)
  adjust = adjust_aim(x1, y1, x2, y2)
  d_x *= adjust[0]
  d_y *= adjust[1]
  x_y_velocity = [d_x, d_y]
  return x_y_velocity

#From a shooter at point x1, y1, fire a bullet at velocity v at angle, provided in degrees, from the positive x axis, calculated clockwise. Returns the x and y velocities in a list.
def sweep(x1, y1, v, angle):
  r_dir = math.radians(angle)
  d_y = v*math.sin(r_dir)
  d_x = v*math.cos(r_dir)
  x_y_velocity = [d_x, d_y]
  return x_y_velocity

