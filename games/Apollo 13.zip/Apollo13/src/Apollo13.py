import pygame
import globals
import random
import aiming
import markmail
from Sound import SoundEngine

pygame.init()
screen = pygame.display.set_mode((600,800))
clock = pygame.time.Clock()
 
 
 # set up global sound effects
GlobalSounds = SoundEngine.EffectList ()
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ping.wav", "ping")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ping2.wav", "ping2")
#GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ambiance_1.wav", "amb1")
#GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ambiance_2.wav", "amb2")
#GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ambiance_3.wav", "amb3")
#GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ambiance_4.wav", "amb4")
#GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "ambiance_5.wav", "amb5")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "player_gun.wav", "player_gun")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "player_missile.wav", "player_missile")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "player_bomb.wav", "player_bomb")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "thruster.wav", "thruster")
GlobalSounds.AddEffect (globals.SOUNDEFFECTSDIR + "stalin_laugh.wav", "laugh")

 
 
####################################
## HUD Class: Contains score and lives displayer   ##
####################################
 
class HUD:
	def __init__(self):
		self.score = 0
		self.unalteredscore = 0
		self.livesholder = 0
		
		self.victory = False
		self.death = False
		self.frames = 0
		self.textqueue = []
		self.soundqueue = []
		
		#load the hud images
		self.livesimage = pygame.image.load(globals.ARTDIR + "apollo 13 life icon.png")
		self.empimage = pygame.image.load(globals.ARTDIR + "emp satellite icons.png")
		self.empimage.set_colorkey((0,255,0))
		
		# load the hud fonts
		self.font = pygame.font.Font(globals.FONTSTEAK, 24)
		self.bigfont = pygame.font.Font(globals.FONTSTEAK, 48)
		
		
	def addpoints(self, points):
		if self.death == False:
			self.score = self.score + points
	
	def displayText(self, text, position, color):
		if self.death == False:
			text = self.font.render(text, 1, color)
			screen.blit(text, pygame.Rect(position[0], position[1], position[2], position[3]))
		
	def enqueueText(self, text, position, color, starttime, stoptime):
		realstart = starttime * globals.FRAMESPERSECOND
		realstop = stoptime * globals.FRAMESPERSECOND
		self.textqueue.append([realstart, realstop, text, position, color])
		
	def enqueueSound (self, id, time):
		time *= globals.FRAMESPERSECOND
		self.soundqueue.append ([id, time])

		
	def draw(self, PlayerShip, empcooldown):
		
		self.frames = self.frames + 1

		
		if self.victory == True and self.death == False:
			
			#bit of hackery because transit implies that the ship has finished animating...
			#so we check to make sure transit is set or if the score updated score has already been calculated to display the end of level framing
			if globals.TRANSIT == True or self.unalteredscore != 0:
				
			
				youwin = self.bigfont.render("Stage Completed!", 1, (200, 200, 0))
				
				subtotal = self.font.render("Points Earned:" , 1, (100, 100, 255))
				subtotal_data = self.font.render("%s" % (self.unalteredscore), 1, (100, 100, 255))
				
				livesleft = self.font.render("Lives Remaining:", 1, (100, 100, 255))
				livesleft_data = self.font.render("%s X 1000" % (self.livesholder), 1, (100, 100, 255))
				
				finalscore = self.font.render("Final Score:", 1, (255, 255, 255))
				finalscore_data= self.font.render("%s" % (self.score), 1, (255, 255, 255))
				
				screen.blit(youwin, pygame.Rect(70,50, 200, 200))
				
				screen.blit(subtotal, pygame.Rect(70, 150, 200, 200))
				screen.blit(livesleft, pygame.Rect(70, 175, 200, 200))
				screen.blit(finalscore, pygame.Rect(70, 220, 200, 200))
				
				screen.blit(subtotal_data, pygame.Rect(430, 150, 200, 200))
				screen.blit(livesleft_data, pygame.Rect(430, 175, 200, 200))
				screen.blit(finalscore_data, pygame.Rect(430, 220, 200, 200))
				
				
				
			if globals.TRANSIT == False and self.unalteredscore == 0: # add points per life if this is the first time we've seen the victory condition
				
				
				self.livesholder = PlayerShip.lives
				self.unalteredscore = self.score + (PlayerShip.lives * 1000)
				self.addpoints((PlayerShip.lives * 1000))
				
				globals.TRANSIT = True
				
			
		elif self.death == False: #if we're not dead and havent won (normal hud state)
			curscore = self.font.render("Score: %s" % (self.score), 1, (255, 255, 0))
			
			
			livesleft = self.font.render("%s" % (PlayerShip.lives), 1, (255,255,0))
			
			missiontime = self.font.render("Mission Time: T+%s" % (self.frames // globals.FRAMESPERSECOND), 1, (255,255,0))
			
			
			#right justify the lives
			if PlayerShip.lives >= 10:
				screen.blit(livesleft, pygame.Rect(550, 10, 100, 100))
			else:
				screen.blit(livesleft, pygame.Rect(560, 10, 100, 100))
			
			
			#dynamically render the emp indicator
			if empcooldown < globals.BOMBDELAY:
				screen.blit(self.empimage, pygame.Rect(550, 50, 53, 41))
			else:
				screen.blit(self.empimage, pygame.Rect(550, 50, 53, 41), pygame.Rect(55, -1, 53,41))
				
			
			screen.blit(self.livesimage, pygame.Rect(580, 2, 41, 106))
			screen.blit(curscore, pygame.Rect(10, 20, 100, 100))
			screen.blit(missiontime, pygame.Rect(10, 0, 100, 100))
			
			for textobject in self.textqueue:
				if textobject[0] <= self.frames:
					self.displayText(textobject[2], textobject[3], textobject[4])
				if textobject[1] < self.frames:
					self.textqueue.remove(textobject)
					
			for soundobject in self.soundqueue:
				if soundobject[1]  <= self.frames:
					GlobalSounds.PlayEffectById (soundobject[0])
					self.soundqueue.remove (soundobject)
			
		else: # if we're dead and out of lives display the game over stuff
			gameovermsg = self.bigfont.render("Game Over!!", 1, (200, 200, 0))
			
			finalscore = self.font.render("Final Score:", 1, (255, 255, 255))
			finalscore_data= self.font.render("%s" % (self.score + (PlayerShip.lives * 1000)), 1, (255, 255, 255))
			
			screen.blit(gameovermsg, pygame.Rect(160,250, 300, 300))
			screen.blit(finalscore, pygame.Rect(200, 350, 200, 200))
			screen.blit(finalscore_data, pygame.Rect(400, 350, 200, 200))
		
	def reset(self):
		self.unalteredscore = 0
		self.victory = False
		self.death = False
		self.frames = 0
		self.textqueue = []
		self.soundqueue = []


hud = HUD()
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 
 
 
 
 
 
 
 
 
 
 
#####################
## Player Ship Class           ##
#####################
 
 
class ShipTemplate(pygame.sprite.Sprite):
        def __init__(self, stage, init_pos):
		pygame.sprite.Sprite.__init__(self)
		
		self.width = 0
		self.height = 0
		
		# initialize the player sound object
		self.effects = SoundEngine.EffectList()
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "player_die.wav", "die")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "player_hit.wav", "hit")
		#self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "engine_loop.wav", "engine")
		#self.effects.LoopEffectById ("engine")
		
		# set up the ship depending on the stage
		if stage == globals.STAGE_1:
			self.pic = globals.ARTDIR + "apollo13_stage1animated.png"
			self.deathpic = globals.ARTDIR + "apolloboom1.png"
			self.width = 57
			self.height = 174
			
			self.deathoffset = (46, 32)
			
		elif stage == globals.STAGE_2:
			self.pic = globals.ARTDIR + "Apollo13_stage2animated.png"
			self.deathpic = globals.ARTDIR + "apolloboom2.png"
			self.width = 57
			self.height = 121
			
			self.deathoffset = (46, 32)
			
			
		elif stage == globals.STAGE_3:
			self.pic = globals.ARTDIR + "Apollo13_stage3animated.png"
			self.deathpic = globals.ARTDIR + "apolloboom3.png"
			self.width = 57
			self.height = 101
		
			self.deathoffset = (52, 30)
		
		#save a copy of the widths so we can resize back after animating
		self.origwidth = self.width
		self.origheight = self.height
		
                self.image = pygame.image.load(self.pic)
		self.image.set_colorkey((0, 255, 0))
		self.rect = pygame.Rect(init_pos[0], init_pos[1], self.width, self.height)

                self.goingup = 0
                self.goingdown = 0
                self.goingleft = 0
                self.goingright = 0
                
                #velocities
                self.vertvel = 0
                self.horizvel = 0
		
		self.hp = 1
		self.lives = globals.PLAYER_LIVES
		
		self.frame = 0
		self.leftpadding = 0

		self.state = globals.PLAYER_NORMAL
		self.dyingframe = 0
		self.resframe = 0
		self.fadeout = False

        def update(self):

		if self.state == globals.PLAYER_NORMAL or self.state == globals.PLAYER_REVIVING:
			
			if globals.ISSHIPINTRANSIT> 300:
				if globals.GOTOSCREEN == "Mission 1":
					globals.GOTOSCREEN = "Mission 2"
				elif globals.GOTOSCREEN == "Mission 2":
					globals.GOTOSCREEN = "Mission 3"
				elif globals.GOTOSCREEN == "Mission 3":
					globals.GOTOSCREEN = "Mission Stalin"
				elif globals.GOTOSCREEN == "Mission Stalin":
					globals.GOTOSCREEN = "Victory"
				goto_handler(globals.GOTOSCREEN)
			
			if globals.TRANSIT == False:
				# playership animation stuff
				if self.frame % 4 == 0:
					# If in Mission 3 or Mission Stalin
					if globals.GOTOSCREEN == "Mission 3" or globals.GOTOSCREEN == "Mission Stalin":
						if self.leftpadding == 3*self.width:
							self.leftpadding = 0
							self.frame = 0
					# If transitioning from Mission 2 to Mission 3.
					# Necessary to handle the change in ship width.
					elif globals.GOTOSCREEN == "Mission 2" and globals.ISSHIPINTRANSIT > 0:
						if self.leftpadding == 3*self.width:
							self.leftpadding = 0
							self.frame = 0
					if self.leftpadding == 7*self.width:
						self.leftpadding = 0
						self.frame = 0
					else:
						self.leftpadding = self.leftpadding + self.width
			
				
			elif globals.TRANSIT == True:
				globals.ISSHIPINTRANSIT= globals.ISSHIPINTRANSIT+ 1
				if globals.ISSHIPINTRANSIT < 2:
					# playership stage transition animation stuff
					if globals.GOTOSCREEN == "Mission 1":
						self.pic = globals.ARTDIR + "apollo13_level1transition.png"
						self.width = 57
						self.height = 232
						self.image = pygame.image.load(self.pic)
						self.image.set_colorkey((0, 255, 0))
					elif globals.GOTOSCREEN == "Mission 2":
						self.pic = globals.ARTDIR + "apollo13_level2transition.png"
						self.width = 57
						self.height = 163
						self.image = pygame.image.load(self.pic)
						self.image.set_colorkey((0, 255, 0))
					elif globals.GOTOSCREEN == "Mission 3":
						self.pic = globals.ARTDIR + "apollo13_level3transition.png"
						self.width = 57
						self.height = 105
						self.image = pygame.image.load(self.pic)
						self.image.set_colorkey((0, 255, 0))
				
				
				if self.frame % 4 == 0:
					if self.leftpadding >= 15*self.width:
						if globals.GOTOSCREEN == "Mission 1":
							self.__init__(globals.STAGE_2, self.rect.topleft)
						elif globals.GOTOSCREEN == "Mission 2":
							self.__init__(globals.STAGE_3, self.rect.topleft)
						elif globals.GOTOSCREEN == "Mission 3":
							self.__init__(globals.STAGE_3, self.rect.topleft)
						globals.TRANSIT = False
					else:	
						if globals.GOTOSCREEN != "Mission Stalin":
							self.leftpadding = self.leftpadding + self.width
			
			self.frame = self.frame + 1
			if globals.ISSHIPINTRANSIT> 0:
				globals.ISSHIPINTRANSIT= globals.ISSHIPINTRANSIT+ 1


			if self.goingup == 1:
				self.vertvel -= globals.PLAYERSHIPACCEL
			if self.goingdown == 1:
				self.vertvel += globals.PLAYERSHIPACCEL
			if self.goingleft == 1:
				self.horizvel -= globals.PLAYERSHIPACCEL
			if self.goingright == 1:
				self.horizvel += globals.PLAYERSHIPACCEL
			if self.goingup == 0 and self.goingdown == 0:
				self.vertvel = (self.vertvel/1.05)
			if self.goingleft == 0 and self.goingright == 0:
				self.horizvel = (self.horizvel/1.05)

			temptop = self.rect.move(self.horizvel,self.vertvel).top
			tempbottom = self.rect.move(self.horizvel,self.vertvel).bottom
			templeft = self.rect.move(self.horizvel,self.vertvel).left
			tempright = self.rect.move(self.horizvel,self.vertvel).right
			if temptop < 0:
				self.vertvel = 0
				self.rect.top = 0
			elif temptop < 400:
				self.rect.move_ip(0,2)
			if tempbottom > 800:
				self.vertvel = 0
				self.rect.bottom = 800
			if templeft < 0:
				self.horizvel = 0
				self.rect.left = 0
			if tempright > 600:
				self.horizvel = 0
				self.rect.right = 600
			self.rect.move_ip(self.horizvel,self.vertvel)
			
			# add in bullet collision detection here if we're not reviving
			
			if self.state == globals.PLAYER_REVIVING:
				
				self.resframe = self.resframe + 1 #increment the counter to know if we're blinking or not...
				
				alpha = self.image.get_alpha()
				
				if alpha == None:
					alpha = 0
					self.image.set_alpha(0)
				
				if self.fadeout == False:
					self.image.set_alpha(alpha + 20)
					if alpha > 200:
						self.fadeout = True
				else:
					self.image.set_alpha(alpha - 20)
					if alpha < 25:
						self.fadeout = False
				
				if self.resframe > 60:
					self.state = globals.PLAYER_NORMAL
					self.image.set_alpha(255)
			
		elif self.state == globals.PLAYER_DYING:
			
			self.dyingframe = self.dyingframe + 1
			
			
			#move the death animation
			if self.dyingframe % 4 == 0:
				self.leftpadding = self.leftpadding + 155
			
			#move to the next state
			if self.dyingframe > globals.SHIP_EXPLOSION_TIME:
				self.state = globals.PLAYER_DEAD 
			
			
		elif self.state == globals.PLAYER_DEAD:
			
			#reset the tickers
			self.dyingframe = 0
			self.resframe = 0
			self.fadeout = False
			self.leftpadding = 0
			
			#reset the velocities and sizes
			self.vertvel = 0
			self.horizvel = 0
			
			self.width = self.origwidth
			self.height = self.origheight
			
			
			self.image = pygame.image.load(self.pic) # reset the image now that we're done blowing up
			self.image.set_colorkey((0, 255, 0))
			
			# if we're dead, but we have more lives, set the state to ressurecting
			if self.lives > 1:
				self.lives = self.lives - 1 #reduce lives
				self.hitpoints = globals.PLAYER_HP # reset HP meter
				
				self.state = globals.PLAYER_REVIVING #indicate that we're reviving
				self.rect = pygame.Rect((275,600), (self.width, self.height)) # reposition the craft
				
			else:	 # if we're dead and out of lives....
				self.image.set_alpha(0) #hide the blown up ship
				self.rect = pygame.Rect((300,10000), (0, 0)) #and move it off the screen
				hud.death = True # tell the hud we're dead
				
			
		
	def hit(self, hitpoints):
		self.effects.PlayEffectById ("hit")
		self.hp = self.hp - hitpoints
		if self.hp < 1:
			self.die()
		
	def die(self):
		self.effects.PlayEffectById ("die")
		#self.effects.StopEffectById ("engine")
		
		self.image = pygame.image.load(self.deathpic)
			
		
		#alter it
		self.width = 156
		self.height= 206
		
		#change the rect so the ship blows up in its real location
		self.rect = pygame.Rect(self.rect.left - self.deathoffset[0], self.rect.top - self.deathoffset[1], self.width, self.height)
		
		self.leftpadding = 0
		
		self.state = globals.PLAYER_DYING
                
		
	


























class ProjectileTemplate(pygame.sprite.Sprite):
	def __init__(self, init_pos, size, pic):
		pygame.sprite.Sprite.__init__(self)
		
		self.image = pygame.image.load(pic)
		self.image.set_colorkey((0, 255, 0))
		
		self.rect = pygame.Rect(init_pos[0], init_pos[1], size[0], size[1])
		
		#velocities
                self.vertvel = 0
                self.horizvel = 0
		
		self.leftoffset = 0 #used to decide what frame to render
		self.topoffset = 0
		
		#var tells us if the projectile should delete itself (i.e. an exploded bomb or tripped mine)
		self.used = 0
		
	

class PlayerProjectile(ProjectileTemplate):
	def __init__(self, init_pos, size, pic):
		
		self.hostile = 0
		ProjectileTemplate.__init__(self, init_pos, size, pic)
		


class HostileProjectile(ProjectileTemplate):
	def __init__(self, init_pos, init_vel):
		
		self.hostile = 1
		self.damage = globals.HOSTILE_BULLET_DAMAGE
		
		ProjectileTemplate.__init__(self, init_pos, (12, 24), globals.ARTDIR + "Communist_Missile.png")
		
		
		#play some sound!
		#GlobalSounds.PlayEffectById ("player_gun")
		# removed becasue enemy type specific sounds are in enemy shoot functions
		
		
		self.vertvel = init_vel[0]
		self.horizvel = init_vel[1]
		
		self.framecounter = 0
		self.leftoffset = 0
	
	# default bullet updater...just makes it move downward
	def update(self, projectile_list, PlayerShip):
		self.vertvel += globals.HOSTILE_BULLET_ACCEL
		self.rect.move_ip(self.horizvel, self.vertvel)
		if self.rect.top > 800:
			projectile_list.remove(self)
			
		self.framecounter = self.framecounter + 1
		
		w = 12
		
		if self.framecounter % 4 == 0:
				if self.leftoffset == 0:
					self.leftoffset = 1*w
				elif self.leftoffset == 1*w:
					self.leftoffset = 0
					self.framecounter = 0


class HostileAimedProjectile(ProjectileTemplate):
	def __init__(self, init_pos, init_vel):
		
		self.hostile = 1
		self.damage = globals.HOSTILE_BULLET_DAMAGE
		
		ProjectileTemplate.__init__(self, init_pos, (6, 17), globals.ARTDIR + "Satellite_Bullet.png")
		
		#play some sound!
		#GlobalSounds.PlayEffectById ("missile")
		# removed becasue enemy type specific sounds are in enemy shoot functions
		
		self.vertvel = init_vel[0]
		self.horizvel = init_vel[1]
		
	
	#awesome omg bullet updater that auto aims!
	def update(self, projectile_list, PlayerShip):
		self.rect.move_ip(self.horizvel, self.vertvel)
		if self.rect.top > 800:
			projectile_list.remove(self)
			
			




class TheHammer(ProjectileTemplate):
	def __init__(self, init_pos, init_vel):
		
		ProjectileTemplate.__init__(self, init_pos, (30, 30), globals.ARTDIR + "Sickle_Hammer.png")
		
		self.hostile = 1
		self.damage = globals.HOSTILE_BULLET_DAMAGE
		
		self.width = 30
		self.topoffset = 30
		self.horizvel = -4
		
		self.frame = 0
		
	def update(self, projectile_list, PlayerShip):
		
		self.rect.move_ip(self.horizvel,self.vertvel)
		
		#increment counter
		self.frame = self.frame + 1
		
		if self.frame % 30 == 0:
			vel = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.STALIN_MISSILE_SPEED, 0)

			self.vertvel = vel[1]
			self.horizvel = vel[0]/2
		if self.frame == 200:
			self.used = 1
	
			
		# update animation
		if self.frame % 4 == 0:
			if self.leftoffset < self.width * 3:
				self.leftoffset  = self.leftoffset  + self.width
			else:
				self.leftoffset  = 0
		
		
		
class TheSickle(ProjectileTemplate):
	def __init__(self, init_pos, init_vel):
		ProjectileTemplate.__init__(self, init_pos, (30, 30), globals.ARTDIR + "Sickle_Hammer.png")
		
		self.hostile = 1
		self.damage = globals.HOSTILE_BULLET_DAMAGE
		
		self.horizvel = 4
		self.width = 30
		
		self.frame = 0
				
		self.velholder = init_vel
	
	
	def update(self, projectile_list, PlayerShip):
		
		self.rect.move_ip(self.horizvel,self.vertvel)
		
		#increment counter
		self.frame = self.frame + 1
		
		if self.frame % 30 == 0:
			vel = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.STALIN_MISSILE_SPEED, 0)

			self.vertvel = vel[1]
			self.horizvel = vel[0]/2
		
		if self.frame == 200:
			self.used = 1
	
		# update animation
		if self.frame % 4 == 0:
			if self.leftoffset < self.width * 3:
				self.leftoffset  = self.leftoffset  + self.width
			else:
				self.leftoffset  = 0
		

















class BulletTemplate(PlayerProjectile):
        def __init__(self, init_pos):
		
		PlayerProjectile.__init__(self, init_pos, (6, 17), globals.ARTDIR + "Apollo_Bullet2.png")
		
		self.damage = globals.BULLET_DAMAGE
		
		GlobalSounds.PlayEffectById ("player_gun")

        def update(self, projectile_list, PlayerShip):
                self.vertvel -= globals.BULLETACCEL
                self.rect.move_ip(self.horizvel,self.vertvel)
                if self.rect.top < 0:
                        projectile_list.remove(self)
			
			
class MissileTemplate(PlayerProjectile):
        def __init__(self, init_pos):
		
		PlayerProjectile.__init__(self, init_pos, (26, 60), globals.ARTDIR + "Apollo_Missile3.png")
		
		self.framecounter = 0
		
                #velocities
                self.vertvel = 0
                self.horizvel = 0
		
		self.damage = globals.MISSILE_DAMAGE
		
		GlobalSounds.PlayEffectById ("player_missile")
		
	def update(self, projectile_list, PlayerShip):
                self.vertvel -= globals.MISSILEACCEL
                self.rect.move_ip(self.horizvel,self.vertvel)
		
                if self.rect.top < 0:
                        projectile_list.remove(self)

		self.framecounter = self.framecounter + 1
		
		w = 26
		
		if self.framecounter % 5 == 0:
				if self.leftoffset == 0:
					self.leftoffset = 1*w
				elif self.leftoffset == 1*w:
					self.leftoffset = 2*w
				elif self.leftoffset == 2*w:
					self.leftoffset = 3*w
				elif self.leftoffset == 3*w:
					self.leftoffset = 4*w
				elif self.leftoffset == 4*w:
					self.leftoffset = 0
					self.framecounter = 0


# # # # # # # # # # # # # # # # # # # # # # # # 
# The Bomb is not necessarily in the game,			#
# I wanted to leave it for good measure.			#
# If we want it, it's going to have to wait until the end.  #
# # # # # # # # # # # # # # # # # # # # # # # #

class BombTemplate(PlayerProjectile):
	
        def __init__(self, pic, init_pos):
		
		PlayerProjectile.__init__(self, init_pos, (400, 400), pic)
		
                #velocities
                self.vertvel = 0
                self.horizvel = 0
		
		self.leftoffset = 0
		self.frame = 0
		
		self.used = 0
		self.damage = 0 #OMG DAMAGE
		
		GlobalSounds.PlayEffectById ("player_bomb")

        def update(self, projectile_list, PlayerShip):
                
		if self.used == 0:
			self.frame = self.frame + 1
		
			w = 400
			
			if self.frame % 3 == 0:
				if self.leftoffset == 9*w:
					self.leftoffset = 0
					self.frame = 0
					self.used = 1
					
				else:
					self.leftoffset = self.leftoffset + w



	



























######################
## Hostile Ship Stuff            ##
######################

class HostileShipTemplate(pygame.sprite.Sprite):
	def __init__(self, init_vel, init_pos, shipsize, pic):
		# initialize the sprite
		pygame.sprite.Sprite.__init__(self)
		
		#load the image
		self.image = pygame.image.load(pic)
		self.image.set_colorkey((0, 255, 0))
		
		#save the velocities locally
		self.horizvel = init_vel[0]
		self.vertvel= init_vel[1]
		
		self.state = 1
		self.timeleft = globals.SHIP_EXPLOSION_TIME
		
		self.hp = 1
		
		self.firecooldown = 0
		
		# initialize the sound object
		self.effects = SoundEngine.EffectList()
		
		#initialize the rect
		self.rect = pygame.Rect(init_pos[0], init_pos[1], shipsize[0], shipsize[1])
		
		#set up the stuff for the death animation
		self.frame = 0
		self.leftpadding = 0
		
		self.emptime = 0
		
	def update(self, projectile_list, PlayerShip):
		
		if self.emptime == 0: # if we're not emped
			#move the current rect by the velocity
			self.rect.move_ip(self.horizvel,self.vertvel)
			
		else:
			self.emptime = self.emptime - 1
			
			
		if self.state == 1: # under normal state
			#check for going off the screen
			if self.rect.bottom < -25 or self.rect.top > 825 or self.rect.right < -25 or self.rect.left > 625:
				
				return globals.HOSTILE_DEAD #the ship is gone from the screen, its as good as dead
			else:				
				
				
				for projectile in projectile_list:
					if self.rect.colliderect(projectile.rect) and projectile.hostile == 0:
						#We've been hit by a projectile
						#destroy the projetile in the collision
						projectile_list.remove(projectile)
						
						return self.hit(projectile.damage) # run the hit routine and return its value
				
				if self.rect.colliderect(PlayerShip.rect):
					if PlayerShip.state != globals.PLAYER_REVIVING:
						PlayerShip.hit(globals.RAMMING_DAMAGE) # this should kill the player...but who knows
						
					self.hit(globals.RAMMING_DAMAGE); # omgy hitz massive lawlz

				
				#if we're not dead and not emped, run the fireing routine
				if self.emptime == 0:
					self.firecooldown = self.firecooldown + 1
									
					if self.firecooldown == self.firingdelay:
						
						self.shoot(projectile_list, PlayerShip)
						self.firecooldown = 0
						
				
				return globals.HOSTILE_NORMAL
		elif self.state == 2 and self.timeleft > 0:
			#dying state
			self.timeleft = self.timeleft - 1
			self.frame = self.frame + 1
			
			# horrible animation blit hack
			if self.frame % 4 == 0:
				if self.leftpadding == 7*self.framedimensions[0]:
					#self.leftpadding = 0
					pass
				else:
					self.leftpadding = self.leftpadding + self.framedimensions[0]
				
			
			return globals.HOSTILE_DYING
		else:
			self.state = 3 #dead, and done animating.
			return globals.HOSTILE_DEAD #tell the renderer that we're dead, done showing that we're dead and can safely be deleted
				

			
			
	
	def die(self):
		
		self.image = pygame.image.load(self.death_animation)
		self.image.set_colorkey((0, 255, 0))
		
		self.rect = pygame.Rect(self.rect.left + self.frameoffset[0], self.rect.top + self.frameoffset[1], self.framedimensions[0], self.framedimensions[1])
		
		self.state = 2
		self.effects.PlayEffectById ("die")
		hud.addpoints(self.worth)
		
		
	def hit(self, points):
		self.effects.PlayEffectById ("hit")
		self.hp = self.hp - points
		
		if self.hp < 1:
			self.die()
			return globals.HOSTILE_DYING
		else:
			return globals.HOSTILE_NORMAL

	#default shooting algorithm
	def shoot(self, projectile_list, PlayerShip):
		pass





class ZeppelinTemplate(HostileShipTemplate):
	def __init__(self, init_vel, init_pos):
		HostileShipTemplate.__init__(self, init_vel, init_pos, (110, 226), globals.ARTDIR + "zeppelin_finish.png")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "zepplin_die.wav", "die")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "zepplin_hit.wav", "hit")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "zepplin_fire.wav", "fire")
		self.hp = globals.ZEP_HEALTH
		self.worth = 150
		
		self.framedimensions = ( 140 , 253 )
		self.frameoffset = ( -15 , 0 )
		
		# weapons fire hardpoints
		self.hardpoints = [(18, 180), (96, 180)]
		
		self.firingdelay = globals.ZEP_FIRE_DELAY + random.randint(globals.HOSTILE_COOLDOWN_RANDOM_BOTTOM, globals.HOSTILE_COOLDOWN_RANDOM_TOP)
		
		self.death_animation =  globals.ARTDIR + "zeppelin_deathanimation_2.png"
			
	

class Zeppelin(ZeppelinTemplate):
	def __init__(self, init_vel, init_pos):
		ZeppelinTemplate.__init__(self, init_vel, init_pos)
	
	def shoot(self, projectile_list, PlayerShip):
		# fire a projectile from all listed hardpoints
		for hp in self.hardpoints:
			self.effects.PlayEffectById ("fire")
			projectile_list.append(HostileProjectile( (self.rect.left + hp[0], self.rect.top + hp[1]), (0, 0) ) )
		

class FunkyZeppelin(ZeppelinTemplate):
	def __init__(self, init_vel, init_pos):
		ZeppelinTemplate.__init__(self, init_vel, init_pos)
		self.counter = 0
	
	def update(self, projectile_list, PlayerShip):
		self.counter = self.counter + 1
		if (self.counter % 120) == 0:
			self.horizvel = self.horizvel * -1
		
		return ZeppelinTemplate.update(self, projectile_list, PlayerShip)
		
	def shoot(self, projectile_list, PlayerShip):
		# fire a projectile from all listed hardpoints
		for hp in self.hardpoints:
			self.effects.PlayEffectById ("fire")
			projectile_list.append(HostileProjectile( (self.rect.left + hp[0], self.rect.top + hp[1]), (0, 0) ) )

# BALLS HARD ZEPPE!
class BallsZeppelin(ZeppelinTemplate):
	def __init__(self, init_vel, init_pos):
		ZeppelinTemplate.__init__(self, init_vel, init_pos)
		
	def shoot(self, projectile_list, PlayerShip):
		# fire a projectile from all listed hardpoints
		for hp in self.hardpoints:
			self.effects.PlayEffectById ("fire")
			aimvalues = aiming.aim(self.rect.left + hp[0], self.rect.top + hp[1], PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.SAT_BULLET_SPEED, 0)
			projectile_list.append( HostileAimedProjectile( (self.rect.left + hp[0], self.rect.top + hp[1]),  (aimvalues[1], aimvalues[0])) )
		
		
		
class SpaceMig(HostileShipTemplate):
	def __init__(self, init_vel, init_pos):
		HostileShipTemplate.__init__(self, init_vel, init_pos, (74, 73), globals.ARTDIR + "spaceMIG.png")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "spacemig_die.wav", "die")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "spacemig_hit.wav", "hit")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "spacemig_fire.wav", "fire")
		self.hp = globals.MIG_HEALTH
		self.worth = 100
		
		self.framedimensions = ( 50 , 50 )
		self.frameoffset = ( 0 , 0 )
		
		self.death_animation =  globals.ARTDIR + "Explosion.png"
		
		self.firingdelay = globals.MIG_FIRE_DELAY + random.randint(globals.HOSTILE_COOLDOWN_RANDOM_BOTTOM, globals.HOSTILE_COOLDOWN_RANDOM_TOP)
	#shoot straight and trueeeee
	def shoot(self, projectile_list, PlayerShip):
		self.effects.PlayEffectById ("fire")
		projectile_list.append( HostileProjectile( (self.rect.centerx, self.rect.centery), (0,1) ) )
		
		
		
		
class AttackSat(HostileShipTemplate):
	def __init__(self, init_vel, init_pos):
		
		HostileShipTemplate.__init__(self, init_vel, init_pos, (51, 46), globals.ARTDIR + "attacksattelite_one.png")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_die.wav", "die")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_hit.wav", "hit")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_fire.wav", "fire")
		self.hp = globals.SAT_HEALTH
		self.worth = 80
		
		self.framedimensions = ( 50 , 50 )
		self.frameoffset = ( 0 , 0 )
		
		self.firingdelay = globals.SAT_FIRE_DELAY + random.randint(globals.HOSTILE_COOLDOWN_RANDOM_BOTTOM, globals.HOSTILE_COOLDOWN_RANDOM_TOP)
		self.death_animation =  globals.ARTDIR + "Explosion.png"
		
	def shoot(self, projectile_list, PlayerShip):
		#deadly autoaiming sat!
		self.effects.PlayEffectById ("fire")
		aimvalues = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.SAT_BULLET_SPEED, 0)
		projectile_list.append( HostileAimedProjectile( (self.rect.centerx, self.rect.centery),  (aimvalues[1], aimvalues[0])) )

		
		
		
class AttackSat2(HostileShipTemplate):
	def __init__(self, init_vel, init_pos):
		HostileShipTemplate.__init__(self, init_vel, init_pos, (80, 36), globals.ARTDIR + "attacksatellite_two.png")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_die.wav", "die")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_hit.wav", "hit")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "attacksat_fire.wav", "fire")
		self.hp = globals.SAT_HEALTH
		self.worth = 80
		
		self.framedimensions = ( 50 , 50 )
		self.frameoffset = ( 0 , 0 )
		
		self.firingdelay = globals.SAT_FIRE_DELAY + random.randint(globals.HOSTILE_COOLDOWN_RANDOM_BOTTOM, globals.HOSTILE_COOLDOWN_RANDOM_TOP)
		
		self.death_animation =  globals.ARTDIR + "Explosion.png"
		
	def shoot(self, projectile_list, PlayerShip):
		#deadly autoaiming sat!
		self.effects.PlayEffectById ("fire")
		aimvalues = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.SAT_BULLET_SPEED, 0)
		projectile_list.append( HostileAimedProjectile( (self.rect.centerx, self.rect.centery),  (aimvalues[1], aimvalues[0])) )







class Stalin(HostileShipTemplate):
	def __init__(self, init_pos):
		
		
		HostileShipTemplate.__init__(self, (0,0), init_pos, (72, 65), globals.ARTDIR + "stalin_poses.png")
		
		self.hp = globals.STALIN_HEALTH
		self.worth = 3500
		
		self.width = 72
		self.height = 65
		
		self.framedimensions = ( 50 , 50 )
		self.frameoffset = ( 0 , 0 )
		
		self.leftoffset = 0
		self.timeleft = 0
		self.enraged = 0
		
		self.death_animation =  globals.ARTDIR + "Explosion.png" #only 1 here, we'll want to add more in...hehehhe
		self.timeleft = 120

		self.firingdelay = 120 #frames
		
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "stalin_laugh.wav", "live")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "stalin_throw.wav", "throw")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "zepplin_fire.wav", "fire")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "stalin_shotgun.wav", "shotgun")
		self.effects.AddEffect (globals.SOUNDEFFECTSDIR + "stalin_die.wav", "die")
		
		self.healthbar = pygame.Surface((300, 10))
		self.healthbar.fill((255,0,0))
		

		self.effects.PlayEffectById ("live")

	def posenormal(self):
		self.leftpadding = 0 * self.width

	def posegrabbing(self):
		self.leftpadding = 1 * self.width
		
	def posethrow(self):
		self.leftpadding = 2 * self.width
	
	def posegun(self):
		self.leftpadding = 4 * self.width
		
	def poseshotgun(self):
		self.leftpadding = 5 * self.width

	def update(self, projectile_list, PlayerShip):
		
		#EMP: STALIN IGNORES EMP!
		
		self.frame = self.frame + 1 #update frame counter
		#print "at frame %s, moving (%s, %s), state %s, hp = %s" % (self.frame, self.horizvel, self.vertvel, self.state, self.hp)
		
		#display the healthbar
		if self.hp > 0:
			screen.blit(self.healthbar, pygame.Rect(150, 780, 0, 0))
		
		self.rect.move_ip(self.horizvel,self.vertvel)
		
		
		if self.state == 1: # under normal state
			
			
			# decide what the velocity is (stalin moves randomly)
			if self.frame % 60 == 0: 
				# randomize up down movement
				lowerrand = -3
				upperrand = 3
				
				if self.rect.bottom > 400:
					upperrand = -1
				elif self.rect.top < 150:
					lowerrand = 1
				
				self.vertvel = random.randint(lowerrand, upperrand)
				
				
				#randomize left right movement
				lowerrand = -3
				upperrand = 3
				
				if self.rect.left < 100:
					lowerrand = 1
				elif self.rect.right > 450:
					upperrand = -1

				self.horizvel = random.randint(lowerrand, upperrand)
				
				
				# this ensures stalin wont EVER go off the screen too much
				if self.rect.top < 0:
					self.vertvel = 3
				elif self.rect.bottom > 600:
					self.vertvel = - 3
					
				if self.rect.left < 0:
					self.horizvel = 3
				elif self.rect.right > 600:
					self.horizvel = -3
				
				#display it in debug so we have a log
				
			

				
			for projectile in projectile_list:
				if self.rect.colliderect(projectile.rect) and projectile.hostile == 0:
					#We've been hit by a projectile
					#destroy the projetile in the collision
					projectile_list.remove(projectile)
					
					
					return self.hit(projectile.damage) # run the hit routine and return its value
			
			
			# dont check for playership collisions...stalin moves in 3D!
					
			
			#firing stuff
			self.firecooldown = self.firecooldown + 1
			
			if self.firingdelay - self.firecooldown == 45:
				self.posegrabbing()
				
			if self.firingdelay - self.firecooldown == 20:
				
				#check to see if we're enraged first
				if self.enraged == 1:
					self.nextweapon = random.randint(0, 2) #dont use the homing weapons during enrage
				else:
					self.nextweapon = random.randint(0, 3) #pick any weapon
				

				#based on the random, figgure out what to pull out
				if self.nextweapon == 0:
					self.posenormal()
				elif self.nextweapon == 1:
					self.posegun()
				elif self.nextweapon == 2:
					self.poseshotgun()
				elif self.nextweapon == 3:
					self.posethrow()
				
			
			if self.firecooldown == self.firingdelay: 
				if self.nextweapon != 0:
					self.shoot(projectile_list, PlayerShip)
				self.firecooldown = 0
			
			
			return globals.HOSTILE_NORMAL
		elif self.state == 2 and self.timeleft > 0:
			#dying state			
			
			self.timeleft = self.timeleft - 1
			self.frame = self.frame + 1
			
			# horrible animation blit hack
			if self.frame % 4	== 0:
				if self.leftpadding == 7*self.framedimensions[0]:
					self.leftpadding = 0
					
					del self.blowupspots
					self.blowupspots = []
					i = 0
					while i < 15:
						self.blowupspots.append( (random.randint(0,600), random.randint(0,800)) )
						i = i + 1
				else:
					self.leftpadding = self.leftpadding + self.framedimensions[0]
					

				
			for p in self.blowupspots:
				screen.blit(self.image, pygame.Rect(p[0], p[1], self.framedimensions[0], self.framedimensions[1]), pygame.Rect(self.leftpadding, 0, 50,50))

			
			return globals.HOSTILE_DYING
			
			
			
		else:
			self.state = 3 #dead, and done animating.
			del projectile_list
			projectile_list = []
			return globals.HOSTILE_DEAD #tell the renderer that we're dead, done showing that we're dead and can safely be deleted
			
	def die(self):
		self.image = pygame.image.load(self.death_animation)
		self.image.set_colorkey((0, 255, 0))
		
		self.rect = pygame.Rect(self.rect.left + self.frameoffset[0], self.rect.top + self.frameoffset[1], self.framedimensions[0], self.framedimensions[1])
		
		self.vertvel = 0
		self.horizvel = 0
		self.leftpadding = 0
		self.state = 2
		self.effects.PlayEffectById ("die")
		hud.addpoints(self.worth)
		
		self.blowupspots = []
		
		
		i = 0
		while i < 5:
			self.blowupspots.append( (random.randint(0,600), random.randint(0,800)) )
			i = i + 1
		
		
		
	def hit(self, points):
		self.hp = self.hp - points

		if self.hp > 1:
			self.healthbar = pygame.Surface((self.hp * 3, 10))
			self.healthbar.fill((255, 0, 0))
		
		if self.hp < 35 and self.enraged == 0 :
			self.effects.PlayEffectById("live")
			hud.enqueueText("Stalin goes Berzerk!!", (200, 50, 150, 150), (255, 0 , 0), (hud.frames / 30) + 1, (hud.frames / 30) + 10)
			self.enraged = 1 #enrage timer so he goes insane
		
		if self.hp < 1:
			self.die()
			return globals.HOSTILE_DYING
		else:
			return globals.HOSTILE_NORMAL



	#default shooting algorithm
	def shoot(self, projectile_list, PlayerShip):
		
		if self.nextweapon == 1:
			self.effects.PlayEffectById ("fire")
			aimvalues = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.STALIN_BULLET_SPEED, 0)
			projectile_list.append( HostileAimedProjectile( (self.rect.centerx, self.rect.centery),  (aimvalues[1], aimvalues[0])) )
		elif self.nextweapon == 2:
			self.effects.PlayEffectById ("shotgun")
			
			i = -11
			while i < 11:
				aimvalues = aiming.aim(self.rect.centerx, self.rect.centery, PlayerShip.rect.centerx, PlayerShip.rect.centery, globals.STALIN_BULLET_SPEED, i)
				projectile_list.append( HostileAimedProjectile( (self.rect.centerx, self.rect.centery),  (aimvalues[1], aimvalues[0])) )
				i = i + 2
				
		elif self.nextweapon == 3:
			self.effects.PlayEffectById ("throw")
			projectile_list.append(TheHammer( (self.rect.centerx, self.rect.centery), (0, 0)))
			projectile_list.append(TheSickle( (self.rect.centerx, self.rect.centery), (0, 0)))
		
		if self.enraged == 0:
			self.firingdelay = random.randint(40, 60)
		else:
			self.firingdelay = random.randint(25, 35)
			
		self.posenormal()












# main hostiles rendering class

class Hostiles:
	def __init__(self):
		self.hostile_list = []
		self.queue = []
	def create(self, type, init_vel, init_pos):
		if type == "zeppelin":
			self.hostile_list.append(Zeppelin(init_vel, init_pos))
		elif type == "funkyzep":
			self.hostile_list.append(FunkyZeppelin(init_vel, init_pos))
		elif type == "attacksat":
			self.hostile_list.append(AttackSat(init_vel, init_pos))
		elif type == "attacksat2":
			self.hostile_list.append(AttackSat2(init_vel, init_pos))
		elif type == "spacemig" or type== "mig":
			self.hostile_list.append(SpaceMig(init_vel, init_pos))
		elif type == "baller" or type == "ballzep":
			self.hostile_list.append(BallsZeppelin(init_vel, init_pos))
		elif type == "stalin":
			self.hostile_list.append(Stalin(init_pos))
			
	def enqueue(self, type, init_vel, init_pos, seconds):
		# add enemy to the "to be created" queue
		self.queue.append([(seconds*globals.FRAMESPERSECOND), type, init_vel, init_pos])
	
		
	def draw(self, projectile_list, PlayerShip):
		
		# if we're out of guys to kill		
		if hud.victory == True or (len(self.hostile_list) == 0 and len(self.queue) == 0): 
			# this indicates a victory, so notify the hud to set it up
			hud.victory = True
		
			
		else: #process enemies and draw em as expected
			
			
			for object in self.queue:
				object[0] = object[0] - 1 # tick one off the time
				if object[0] == 0: # if its ready to be put up
					self.create(object[1], object[2], object[3])
					self.queue.remove(object)
			
			for object in self.hostile_list:
				#update the object
				
				objectcondition = object.update(projectile_list, PlayerShip) # this handles collision detection and movement
				
				if objectcondition == globals.HOSTILE_DEAD:
					#object is off the screen or dead and we should delete it from the list
					self.hostile_list.remove(object)
					
				elif objectcondition== globals.HOSTILE_NORMAL:
					#if it returns 1 its still valid and on the screen, so draw it normally
					screen.blit(object.image, object.rect, pygame.Rect(object.leftpadding,0,object.rect.width,object.rect.height))
					
				elif objectcondition == globals.HOSTILE_DYING:
					#2 indiates its been hit and has called its death function, but isnt totally done exploding yet
					#this should draw an explosion, but for now we'll continue drawing the object, its set to make a red box
					screen.blit(object.image, object.rect, pygame.Rect(object.leftpadding,0,object.rect.width,object.rect.height))
	
	def empbomb(self, projectile_list):
		
		for projectile in projectile_list:
			projectile.used = 1
			projectile_list.remove(projectile)
			

		for object in self.hostile_list:
			object.emptime = globals.EMP_FREEZE_TIME
		






























############################
## Background Loop Rendering Class   ##
############################


class Background:
	def __init__(self, stage):
		
		if stage == globals.STAGE_1:
			pic = globals.ARTDIR + "3200_stageonebackground.png"
			self.speed = globals.STAGE_1_BACKGROUND_SPEED
			
		if stage == globals.STAGE_2:
			pic = globals.ARTDIR + "3200_stagetwobackground.png"
			self.speed = globals.STAGE_2_BACKGROUND_SPEED
			
		if stage == globals.STAGE_3:
			pic = globals.ARTDIR + "3200_stagethreebackground.png"
			self.speed = globals.STAGE_3_BACKGROUND_SPEED
			
		if stage == globals.STAGE_STALIN:
			pic = globals.ARTDIR + "3200_moonscape.png"
			self.speed = globals.STAGE_2_BACKGROUND_SPEED
			
		self.bgSurface = pygame.image.load(pic)
		self.top = 0
	def draw(self):
		self.top = self.top + self.speed
		if self.top == 2400:
			self.top = 0
		
		screen.blit(self.bgSurface, pygame.Rect(0,0,600,800), pygame.Rect(0,2400-self.top,600,800))



def goto_handler(where):
	
	if where == "Mission 1":
                mission_1()
	elif where == "Mission 2":
		mission_2()
	elif where == "Mission 3":
		mission_3()
	elif where == "Mission Stalin":
		mission_stalin()
	elif where == "Victory":
		victory_screen()
        elif where == "Title Screen":
                title_screen()
        elif where == "Game Over Screen":
                title_screen()
	elif where == "Communism Party":
		communism_party()
	elif where == "QUIT":
		pygame.quit()



def title_screen():
	SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "music_3.ogg")
	
	hud.score = 0
	commie = 0
	last_hit = "none"
	
        try:
                frame = 0
		selection = 1
		
                while globals.GOTOSCREEN == "Title Screen":
                        clock.tick(globals.FRAMESPERSECOND)
                        events = pygame.event.get()
                        for event in events:
				
                                if event.type == pygame.KEYDOWN:
					
					
					#if event.key == pygame.K_1 and globals.DEBUG == True:
					#	globals.GOTOSCREEN = "Mission 1"
					#elif event.key == pygame.K_2 and globals.DEBUG == True:
					#	globals.GOTOSCREEN = "Mission 2"
					#elif event.key == pygame.K_3 and globals.DEBUG == True:
					#	globals.GOTOSCREEN = "Mission 3"
					#elif event.key == pygame.K_4 and globals.DEBUG == True:
					#	globals.GOTOSCREEN = "Mission Stalin"
					if event.key == pygame.K_c and globals.DEBUG == True:
						commie = commie + 1
						if commie > 5:
							globals.GOTOSCREEN = "Communism Party"
						
					elif event.key == pygame.K_ESCAPE:
						globals.GOTOSCREEN = "QUIT"
					elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
						GlobalSounds.PlayEffectById ("ping")
						if selection == 1:
							selection = 2
						else:
							selection = 1
						if event.key == pygame.K_UP:
							if last_hit == "none":
								commies = 1
								last_hit = "up"
							elif last_hit == "up" and commies == 1:
								commies = 2
								last_hit = "up"
							#commies = commies + 1
						elif event.key == pygame.K_DOWN:
							if last_hit == "up" and commies == 2:
								commies = 3
								last_hit = "down"
							elif last_hit == "down" and commies == 3:
								commies = 4
								last_hit = "down"
					elif event.key == pygame.K_SPACE or event.key == pygame.K_RETURN:
						GlobalSounds.PlayEffectById ("ping2")
						if selection == 1:
							globals.GOTOSCREEN = "Mission 1"
						else:
							globals.GOTOSCREEN = "QUIT"
					elif event.key == pygame.K_LEFT:
						if last_hit == "down" and commies == 4:
							commies = 5
							last_hit = "left"
						elif last_hit == "left" and commies == 5:
							commies = 6
							last_hit = "left"
					elif event.key == pygame.K_RIGHT:
						if last_hit == "left" and commies == 6:
							commies = 7
							last_hit = "right"
						elif last_hit == "right" and commies == 7:
							globals.GOTOSCREEN = "Communism Party"
					else:
						pass

                        screen.fill((150,150,150))
			screenImage = pygame.image.load(globals.ARTDIR + "Title_Menu.png")
			screen.blit(screenImage, pygame.Rect(0,0,600,800))
			
			arrow = pygame.image.load(globals.ARTDIR + "Title_Menu_Arrow.png")
			arrow.set_colorkey((0,255,0))
			
			if selection == 1:
				screen.blit(arrow, pygame.Rect(160, 435, 35, 35))
			else:
				screen.blit(arrow, pygame.Rect(160, 495, 35, 35))
			
                        frame += 1
                        pygame.display.update()
			SoundEngine.Update()
                goto_handler(globals.GOTOSCREEN)
        except:
                print pygame.error()
		
		
def communism_party():
	print "Communism, it's a party!"
	randnum = random.randint(0,2)
	if randnum == 0:
		SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "knightrider.ogg")
	elif randnum == 1:
		SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "ducktales.ogg")
	
	hud.score = 0
	
        try:
                frame = 0
		selection = 1
		
                while globals.GOTOSCREEN == "Communism Party":
                        clock.tick(globals.FRAMESPERSECOND)
                        events = pygame.event.get()
                        for event in events:
				
                                if event.type == pygame.KEYDOWN:
						
					if event.key == pygame.K_ESCAPE or event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
						globals.GOTOSCREEN = "Title Screen"

                        screen.fill((150,150,150))
			screenImage = pygame.image.load(globals.ARTDIR + "Communism Party.png")
			screen.blit(screenImage, pygame.Rect(0,0,600,800))
			
                        frame += 1
                        pygame.display.update()
			SoundEngine.Update()
                goto_handler(globals.GOTOSCREEN)
        except:
                print pygame.error()


def victory_screen():

	screenImage = pygame.image.load(globals.ARTDIR + "victory.png")
	black = pygame.Surface((600,800))
	black.fill((0,0,0))
	font = pygame.font.Font(globals.FONTSTEAK, 24)
	bigfont = pygame.font.Font(globals.FONTSTEAK, 48)
	
	victorymsg = bigfont.render("Victory!", 1, (255, 255, 255))
	scoremsg = font.render("Final Score: ", 1, (100, 100, 255))

	scoredata = font.render("%s" % (hud.score), 1, (100, 100, 255))
	
	endmsg1 = font.render("And as Apollo 13 headed back to earth, Stalin's" , 1, (0, 0, 0))
	endmsg2 = font.render("Corpse lay bleeding on the surface of the moon, ", 1, (0, 0, 0))
	endmsg3 = font.render("and the Soviet Space Forces were in ruins.", 1, (0, 0, 0))
	
	endmsg4 = font.render("All they needed now was a cover story...", 1, (0, 0, 0))
	
	
	
	
        try:
                frame = 0
		
                while globals.GOTOSCREEN == "Victory":
                        clock.tick(globals.FRAMESPERSECOND)
                        events = pygame.event.get()
                        for event in events:
				
                                if event.type == pygame.KEYDOWN:
					
					if event.key == pygame.K_ESCAPE or event.key == pygame.K_RETURN:
						globals.GOTOSCREEN = "Title Screen"
					else:
						pass

                        screen.fill((0,0,0))
			
			
			if frame < 140:
				black.set_alpha(255-(frame*2))
			
			
			
			screen.blit(screenImage, pygame.Rect(0,0,600,800))
			
			screen.blit(victorymsg, pygame.Rect(375, 10, 200, 200))
			screen.blit(scoremsg, pygame.Rect(375, 100, 200, 200))
			screen.blit(scoredata, pygame.Rect(375, 120, 200, 200))
			
			screen.blit(endmsg1, pygame.Rect(10, 550, 200, 600))
			screen.blit(endmsg2, pygame.Rect(10, 570, 200, 600))
			screen.blit(endmsg3, pygame.Rect(10, 590, 200, 600))

			screen.blit(endmsg4, pygame.Rect(100, 650, 200, 600))
			
			screen.blit(black, pygame.Rect(0,0,600,800))
			
			
                        frame += 1
			

                        pygame.display.update()
			SoundEngine.Update()
                goto_handler(globals.GOTOSCREEN)
        except:
                print pygame.error()





































def mission_1():
	SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "music_1.ogg")
	projectile_list = []
	
	PlayerShip = ShipTemplate(globals.STAGE_1, (275,600))
	background = Background(globals.STAGE_1)
	
	globals.TRANSIT = False
	globals.ISSHIPINTRANSIT= 0
	globals.GOTOSCREEN = "Mission 1"
	
	enemies = Hostiles()
	
	hud.reset()
	

	# mission control

	#Stage 1 Mission Preparation

	hud.enqueueSound("amb1", 0.3)
	hud.enqueueText("ALERT", (250,100,200,200), (255,0,0), 0.3, 2)
	hud.enqueueText("Mission 1", (70, 100, 200, 200), (255,0,0), 3, 10)
	hud.enqueueText("Enemy Russian activity has been detected.", (20,130,200,200), (200,200,200), 5, 10)
	hud.enqueueText("Safely bypass all opposition on your", (20,150,200,200), (200,200,200), 5, 10)
	hud.enqueueText("journey to the moon. The Apollo 13", (20,170,200,200), (200,200,200), 5, 10)
	hud.enqueueText("must make it at all costs!", (20,190,200,200), (200,200,200), 5, 10)
	hud.enqueueText("Mission 1 Start", (70, 100, 200, 200), (255, 0, 0), 10, 13)
	hud.enqueueText("Kill All Commies", (70, 120, 200, 200), (255, 0, 0), 10.4, 13)

	#satellite waves
	enemies.enqueue("attacksat", (2,1), (-40,110), 15)
	enemies.enqueue("attacksat", (-1,2), (500,-4), 16)
	enemies.enqueue("attacksat", (1,1), (90,-10), 21)
	enemies.enqueue("attacksat", (-2,0), (620,200), 21)
	enemies.enqueue("attacksat", (2,3), (270,-10), 28)
	enemies.enqueue("attacksat", (0,3), (300,-10), 28)
	enemies.enqueue("attacksat", (-2,3), (330,-10), 28)	
	
	hud.enqueueSound("ping2", 35)

	enemies.enqueue("attacksat2", (-2,2), (620,-20), 38)
	enemies.enqueue("attacksat", (-3,-1), (600,300), 39)
	enemies.enqueue("attacksat", (0,4), (500,0), 39.5)
	enemies.enqueue("attacksat", (1,3), (400,-5), 39.8)

	#MIGs approaching

	hud.enqueueText("Space MIG Squad approaching", (50,100,200,200), (200,200,200), 45, 48)
	iter = 0
	while iter < 4:
		enemies.enqueue("spacemig", (3,4), (100*iter,0), iter+49)
		iter += 1
	iter = 0
	enemies.enqueue("spacemig", (1,5), (300,0), 56)
	enemies.enqueue("spacemig", (-1,5), (420,0), 58)
	enemies.enqueue("spacemig", (1,5), (196,0), 60)
	enemies.enqueue("spacemig", (-1,5), (300,0), 62)
	enemies.enqueue("spacemig", (1,5), (233,0), 64)
	enemies.enqueue("spacemig", (-1,5), (500,0), 66)

	enemies.enqueue("attacksat2", (0,2), (260,0), 70)
	enemies.enqueue("spacemig", (0,4), (120,0), 73)
	enemies.enqueue("spacemig", (0,4), (420,0), 73)
	enemies.enqueue("spacemig", (2,1), (120,0), 75)
	enemies.enqueue("spacemig", (-2,1), (420,0), 75)
	
	
	try:
		IsFire1Down = 0
		IsFire2Down = 0
		IsFire3Down = 0
		bulletframe = globals.BULLETDELAY
		missileframe = globals.MISSILEDELAY
		bombframe = globals.BOMBDELAY
		while globals.GOTOSCREEN == "Mission 1":
			clock.tick(globals.FRAMESPERSECOND)
			events = pygame.event.get()
			for event in events:
					if event.type == pygame.KEYDOWN:
							if event.key == pygame.K_ESCAPE:
									globals.GOTOSCREEN = "Title Screen"
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_1:
									IsFire1Down = 1
							if event.key == pygame.K_2:
									IsFire2Down = 1
							if event.key == pygame.K_3:
									IsFire3Down = 1
							
							if globals.DEBUG == True:
								if event.key == pygame.K_h: #extra lives hack
									PlayerShip.lives = PlayerShip.lives + 1
								if event.key == pygame.K_i: #sort of temporary invincibility hack....
									PlayerShip.state = globals.PLAYER_REVIVING
								if event.key == pygame.K_o: #force level over hack
									enemies.queue = []
									for b in enemies.hostile_list:
										enemies.hostile_list.remove(b)
								if event.key == pygame.K_u: #blow up the player's ship
									PlayerShip.die()
										
					elif event.type == pygame.KEYUP:
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 0
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 0
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 0
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 0
							if event.key == pygame.K_1:
									IsFire1Down = 0
							if event.key == pygame.K_2:
									IsFire2Down = 0
							if event.key == pygame.K_3:
									IsFire3Down = 0
							if event.key == pygame.K_m:
								SoundEngine.SetEffectVolume (0.0)
								SoundEngine.SetMusicVolume (0.0)
							if event.key == pygame.K_n:
								SoundEngine.SetEffectVolume (0.3)
								SoundEngine.SetMusicVolume (0.9)

			if IsFire1Down == 1 and bulletframe > globals.BULLETDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBullet = BulletTemplate((275,600))
					
					newBullet.rect.center = PlayerShip.rect.center
					newBullet.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBullet.vertvel = 0
					else:
							newBullet.vertvel = PlayerShip.vertvel
					newBullet.horizvel = PlayerShip.horizvel
					projectile_list.append(newBullet)
					bulletframe = 0
					
			elif IsFire2Down == 1 and missileframe > globals.MISSILEDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newMissile = MissileTemplate((275,600))
					newMissile.rect.center = PlayerShip.rect.center
					newMissile.rect.move_ip(8,-3)
					if PlayerShip.vertvel > 0:
							newMissile.vertvel = 0
					else:
							newMissile.vertvel = PlayerShip.vertvel
					projectile_list.append(newMissile)
					missileframe = 0
					
			elif IsFire3Down == 1 and bombframe > globals.BOMBDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBomb = BombTemplate(globals.ARTDIR + "EMP.png", (400,400))
					newBomb.rect.center = PlayerShip.rect.center
					newBomb.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBomb.vertvel = 0
					else:
							newBomb.vertvel = PlayerShip.vertvel
					
					enemies.empbomb(projectile_list)
					del projectile_list
					projectile_list = []
					
					projectile_list.append(newBomb)
					
					bombframe = 0
			
			PlayerShip.update()

			for projectile in projectile_list[:]:
				if projectile.rect.bottom < 0 or projectile.rect.top > 800 or projectile.rect.left < 0 or projectile.rect.right > 600:
					projectile_list.remove(projectile)
				elif projectile.used == 1:
					projectile_list.remove(projectile)
				else:
					projectile.update(projectile_list, PlayerShip)
				
			
			# do the drawing
			screen.fill((0,0,0))
			
			background.draw()
			
			
			enemies.draw(projectile_list, PlayerShip)

			#render manager code will go here
			
			for projectile in projectile_list[:]:
					screen.blit(projectile.image, projectile.rect, pygame.Rect(projectile.leftoffset,projectile.topoffset,projectile.rect.width,projectile.rect.height))
					#check for hits on the player
					if projectile.hostile == 1 and PlayerShip.state == globals.PLAYER_NORMAL and projectile.rect.colliderect(PlayerShip.rect):
						PlayerShip.hit(projectile.damage)
						projectile_list.remove(projectile)


			screen.blit(PlayerShip.image, PlayerShip.rect, pygame.Rect(PlayerShip.leftpadding,0,PlayerShip.width,PlayerShip.height))
						
			hud.draw(PlayerShip, bombframe)
			

			bulletframe += 1
			missileframe += 1
			bombframe += 1
			pygame.display.update()
			SoundEngine.Update()
		
                goto_handler(globals.GOTOSCREEN)
	
	except:
		print pygame.error()







def mission_2():
	SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "music_2.ogg")
	projectile_list = []
	
	PlayerShip = ShipTemplate(globals.STAGE_2, (275,600))
	background = Background(globals.STAGE_2)
	
	globals.TRANSIT = False
	globals.ISSHIPINTRANSIT= 0
	globals.GOTOSCREEN = "Mission 2"
	
	enemies = Hostiles()
	
	hud.reset()
	

	# mission control

	hud.enqueueSound("amp1", 0.3)
	hud.enqueueText("Update Transmission", (190,100,200,200), (200,200,200), 0.3, 2)
	hud.enqueueText("Mission 2", (70, 100, 200, 200), (255,0,0), 3, 10)
	hud.enqueueText("The Communists now know of our mission, and", (20,130,200,200), (200,200,200), 5, 10)
	hud.enqueueText("are determined to stop you from reaching the", (20,150,200,200), (200,200,200), 5, 10)
	hud.enqueueText("moon. You must bypass their new defensive", (20,170,200,200), (200,200,200), 5, 10)
	hud.enqueueText("array. Succeed at all costs!", (20,190,200,200), (200,200,200), 5, 10)
	hud.enqueueText("Mission 2 Start", (70, 100, 200, 200), (255, 0, 0), 10, 13)
	hud.enqueueText("Still Kill All Commies", (70, 120, 200, 200), (255, 0, 0), 10.4, 13)

	enemies.enqueue("spacemig", (2,2), (200,-30), 16)
	enemies.enqueue("spacemig", (2,2), (160,-30), 17)
	enemies.enqueue("spacemig", (2,2), (240,-30), 17)
	enemies.enqueue("spacemig", (2,2), (120,-30), 18)
	enemies.enqueue("spacemig", (2,2), (280,-30), 18)

	enemies.enqueue("spacemig", (-2,2), (400,-30), 22)
	enemies.enqueue("spacemig", (-2,2), (360,-30), 23)
	enemies.enqueue("spacemig", (-2,2), (440,-30), 23)
	enemies.enqueue("spacemig", (-2,2), (320,-30), 24)
	enemies.enqueue("spacemig", (-2,2), (480,-30), 24)
	
	enemies.enqueue("spacemig", (0,2), (263,-30), 29)
	enemies.enqueue("spacemig", (0,2), (223,-30), 30)
	enemies.enqueue("spacemig", (0,2), (303,-30), 30)
	enemies.enqueue("spacemig", (0,2), (183,-30), 31)
	enemies.enqueue("spacemig", (0,2), (343,-30), 31)

	#Space Zeppelin Introduction

	hud.enqueueSound("amb2", 27)
	hud.enqueueText("Transmission", (230,100,200,200), (200,200,200), 27, 29)
	hud.enqueueText("A large enemy weapon is approaching.", (50,130,200,200), (200,200,200), 29, 34)
	hud.enqueueText("Prepare for contact in 10.", (50, 150, 200, 200), (200,200,200), 30, 34)

	iter = 0
	while iter <= 1:
		enemies.enqueue("spacemig", (3,2), (-75,0), 38+iter)
		enemies.enqueue("spacemig", (-3,2), (600,0), 40+iter)
		enemies.enqueue("spacemig", (3,2), (-75,0), 42+iter)
		enemies.enqueue("spacemig", (-3,2), (600,0), 44+iter)
		iter = iter + 0.7
	
	#Zeppelin Entrance

	enemies.enqueue("zeppelin", (0,1), (245, -226), 40)

	hud.enqueueText("There's more coming. Watch out.", (50,130,200,200), (200,200,200), 46, 49)

	enemies.enqueue("zeppelin", (0,1), (420,-220), 51)
	enemies.enqueue("zeppelin", (2,1), (-110,-220), 55)
	enemies.enqueue("zeppelin", (-2,1), (600,-220), 55)
	enemies.enqueue("zeppelin", (0,1), (180,-220), 62)

	#Final Approach to Final Approach

	hud.enqueueSound("amb2", 64)
	hud.enqueueText("Apollo 13... do you read?", (50, 130, 200, 200), (200,200,200), 66, 69)
	hud.enqueueText("A large complication has been discovered.", (50, 150, 200, 200), (200,200,200), 66,69)
	hud.enqueueText("Standby and prepare for mission update.", (50, 170, 200, 200), (200,200,200), 66,69)

	enemies.enqueue("attacksat2", (0,2), (260,0), 70)
	enemies.enqueue("spacemig", (3,6), (120,0), 72)
	enemies.enqueue("spacemig", (-3,6), (420,0), 72)
	enemies.enqueue("spacemig", (3,6), (263,0), 74)
	enemies.enqueue("spacemig", (-3,6), (263,0), 74)
	enemies.enqueue("zeppelin", (1,3), (100,0), 76)
	enemies.enqueue("zeppelin", (-1,3), (400,0), 76)
	enemies.enqueue("zeppelin", (0,1), (70,0), 78)
	enemies.enqueue("zeppelin", (0,1), (430,0), 78)
	
	
	
	try:
		IsFire1Down = 0
		IsFire2Down = 0
		IsFire3Down = 0
		bulletframe = globals.BULLETDELAY
		missileframe = globals.MISSILEDELAY
		bombframe = globals.BOMBDELAY
		while globals.GOTOSCREEN == "Mission 2":
			clock.tick(globals.FRAMESPERSECOND)
			events = pygame.event.get()
			for event in events:
					if event.type == pygame.KEYDOWN:
							if event.key == pygame.K_ESCAPE:
									globals.GOTOSCREEN = "Title Screen"
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_1:
									IsFire1Down = 1
							if event.key == pygame.K_2:
									IsFire2Down = 1
							if event.key == pygame.K_3:
									IsFire3Down = 1
							
							if globals.DEBUG == True:
								if event.key == pygame.K_h: #extra lives hack
									PlayerShip.lives = PlayerShip.lives + 1
								if event.key == pygame.K_i: #sort of temporary invincibility hack....
									PlayerShip.state = globals.PLAYER_REVIVING
								if event.key == pygame.K_o: #force level over hack
									enemies.queue = []
									for b in enemies.hostile_list:
										enemies.hostile_list.remove(b)
								if event.key == pygame.K_u: #blow up the player's ship
									PlayerShip.die()
										
					elif event.type == pygame.KEYUP:
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 0
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 0
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 0
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 0
							if event.key == pygame.K_1:
									IsFire1Down = 0
							if event.key == pygame.K_2:
									IsFire2Down = 0
							if event.key == pygame.K_3:
									IsFire3Down = 0
							if event.key == pygame.K_m:
								SoundEngine.SetEffectVolume (0.0)
								SoundEngine.SetMusicVolume (0.0)
							if event.key == pygame.K_n:
								SoundEngine.SetEffectVolume (0.3)
								SoundEngine.SetMusicVolume (0.9)

			if IsFire1Down == 1 and bulletframe > globals.BULLETDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBullet = BulletTemplate((275,600))
					
					newBullet.rect.center = PlayerShip.rect.center
					newBullet.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBullet.vertvel = 0
					else:
							newBullet.vertvel = PlayerShip.vertvel
					newBullet.horizvel = PlayerShip.horizvel
					projectile_list.append(newBullet)
					bulletframe = 0
					
			elif IsFire2Down == 1 and missileframe > globals.MISSILEDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newMissile = MissileTemplate((275,600))
					newMissile.rect.center = PlayerShip.rect.center
					newMissile.rect.move_ip(8,-3)
					if PlayerShip.vertvel > 0:
							newMissile.vertvel = 0
					else:
							newMissile.vertvel = PlayerShip.vertvel
					projectile_list.append(newMissile)
					missileframe = 0
					
			elif IsFire3Down == 1 and bombframe > globals.BOMBDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBomb = BombTemplate(globals.ARTDIR + "EMP.png", (400,400))
					newBomb.rect.center = PlayerShip.rect.center
					newBomb.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBomb.vertvel = 0
					else:
							newBomb.vertvel = PlayerShip.vertvel
					
					enemies.empbomb(projectile_list)
					del projectile_list
					projectile_list = []
					projectile_list.append(newBomb)
					
					bombframe = 0
			
			PlayerShip.update()

			for projectile in projectile_list[:]:
				if projectile.rect.bottom < 0 or projectile.rect.top > 800 or projectile.rect.left < 0 or projectile.rect.right > 600:
					projectile_list.remove(projectile)
				elif projectile.used == 1:
					projectile_list.remove(projectile)
				else:
					projectile.update(projectile_list, PlayerShip)
				
			
			# do the drawing
			screen.fill((0,0,0))
			
			background.draw()
			
			
			enemies.draw(projectile_list, PlayerShip)

			#render manager code will go here
			
			for projectile in projectile_list[:]:
					screen.blit(projectile.image, projectile.rect, pygame.Rect(projectile.leftoffset,projectile.topoffset,projectile.rect.width,projectile.rect.height))
					#check for hits on the player
					if projectile.hostile == 1 and PlayerShip.state == globals.PLAYER_NORMAL and projectile.rect.colliderect(PlayerShip.rect):
						PlayerShip.hit(projectile.damage)
						projectile_list.remove(projectile)


			screen.blit(PlayerShip.image, PlayerShip.rect, pygame.Rect(PlayerShip.leftpadding,0,PlayerShip.width,PlayerShip.height))
						
			hud.draw(PlayerShip, bombframe)
			

			bulletframe += 1
			missileframe += 1
			bombframe += 1
			pygame.display.update()
			SoundEngine.Update()
		
                goto_handler(globals.GOTOSCREEN)
	
	except:
		print pygame.error()
		
		
		
		
		
def mission_3():
	SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "music_3.ogg")
	projectile_list = []
	
	PlayerShip = ShipTemplate(globals.STAGE_3, (275,600))
	background = Background(globals.STAGE_3)
	
	globals.TRANSIT = False
	globals.ISSHIPINTRANSIT= 0
	globals.GOTOSCREEN = "Mission 3"
	
	enemies = Hostiles()
	
	hud.reset()
	

	# mission control
	
	# Stage 3 Mission Preparation

	hud.enqueueSound("amp1", 0.3)
	hud.enqueueText("Update Transmission", (190,100,200,200), (200,200,200), 0.3, 2)
	hud.enqueueText("Mission 3", (70, 100, 200, 200), (255,0,0), 3, 13)
	hud.enqueueText("Stalin has been discovered to be hiding on", (20,130,200,200), (200,200,200), 5, 13)
	hud.enqueueText("the moon. The moon mustn't fall into", (20,150,200,200), (200,200,200), 5, 13)
	hud.enqueueText("Communist hands! Get in there and eliminate", (20,170,200,200), (200,200,200), 5, 13)
	hud.enqueueText("Stalin. Failure is not an option!", (20,190,200,200), (200,200,200), 5, 13)
	hud.enqueueText("Be extra careful. Their defensive platoon is", (20, 220, 200, 200), (200,200,200), 7, 13)
	hud.enqueueText("exceptionally dangerous and very dense.", (20, 240, 200, 200), (200,200,200), 7, 13)
	hud.enqueueText("Mission 3 Start", (70, 100, 200, 200), (255, 0, 0), 13, 17)
	hud.enqueueText("The Final Approach", (70, 120, 200, 200), (255, 0, 0), 13.4, 17)

	#First Generic Wave

	enemies.create("attacksat", (1,1), (100,300))
	enemies.create("attacksat", (-1,1), (475,300))
	enemies.enqueue("spacemig", (0,25), (123,-100), 15)
	enemies.enqueue("spacemig", (0,25), (423,-100), 15)
	enemies.enqueue("attacksat", (3,1), (-30,120), 17)
	enemies.enqueue("attacksat", (-2,2), (400,-30), 18)
	enemies.enqueue("zeppelin", (0,3), (95,-226), 22)
	enemies.enqueue("zeppelin", (0,3), (395,-226), 25)

	#Attack Sat Horizontal Sweep - Removed because it broke the script to end the level

#	iter = 0
#	while iter < 4:
#		enemies.enqueue("attacksat", (-6,0), (600,100), 26+iter)
#		enemies.enqueue("attacksat", (8,0), (-25,150), 29+iter)
#		enemies.enqueue("attacksat", (-10,0), (600,200), 32+iter)
#		enemies.enqueue("attacksat", (12,0), (-25,250), 35+iter)
#		iter += 0.9

	#Space MIG Rush
	
	hud.enqueueText("ALERT", (250,100,200,200), (255,0,0), 35.5, 39)
	hud.enqueueSound("amp4", 40)
	hud.enqueueText("V", (200,100,50,50), (255,0,0), 40, 42)
	enemies.enqueue("spacemig", (0,30), (167,-73), 42)
	hud.enqueueSound("amp4", 43)
	hud.enqueueText("V", (400,100,50,50), (255,0,0), 43, 45)
	enemies.enqueue("spacemig", (0,30), (367,-73), 45)
	hud.enqueueSound("amp4", 46)
	hud.enqueueText("V", (300,100,50,50), (255,0,0), 46, 48)
	enemies.enqueue("spacemig", (0,30), (267,-73), 48)
	hud.enqueueSound("amp4", 49)
	hud.enqueueText("V", (100,100,50,50), (255,0,0), 49, 51)
	enemies.enqueue("spacemig", (0,30), (67,-73), 51)
	hud.enqueueSound("amp4", 52)
	hud.enqueueText("V", (500,100,50,50), (255,0,0), 52, 54)
	enemies.enqueue("spacemig", (0,30), (467,-73), 54)

	#Zeppelins of Doom

	enemies.enqueue("ballzep", (0,2), (490, -226), 55)
	enemies.enqueue("ballzep", (0,2), (0, -226), 55)
	enemies.enqueue("zeppelin", (0,1), (180,-250), 55)
	enemies.enqueue("zeppelin", (0,1), (310,-250), 55)
	enemies.enqueue("zeppelin", (3,3), (120,-226), 68)
	enemies.enqueue("zeppelin", (-3,3), (370,-226), 68)
	enemies.enqueue("ballzep", (2,3), (100,-226), 74)
	enemies.enqueue("ballzep", (-2,3), (390,-226), 74)

	#Final Wave

	hud.enqueueSound("amp2", 78)
	hud.enqueueText("The last enemy wave approaches.", (50,130,200,200), (200,200,200), 79, 84)

	enemies.enqueue("attacksat2", (0,3), (260,-50), 83)
	enemies.enqueue("attacksat2", (0,4), (100,-50), 85)
	enemies.enqueue("attacksat2", (0,4), (420,-50), 85)
	enemies.enqueue("attacksat", (5,4), (-50,-50), 88)
	enemies.enqueue("attacksat", (4,5), (-50,-50), 88)
	enemies.enqueue("attacksat", (-5,4), (600,-50), 88)
	enemies.enqueue("attacksat", (-4,5), (600,-50), 88)
	enemies.enqueue("zeppelin", (0,1), (245,-226), 88)
	enemies.enqueue("spacemig", (1,10), (50,-70), 91)
	enemies.enqueue("spacemig", (-1,10), (523,-70), 91)
	enemies.enqueue("ballzep", (0,2), (100,-226), 93)
	enemies.enqueue("ballzep", (0,2), (390,-226), 93)
	enemies.enqueue("spacemig", (1,10), (80,-70), 94)
	enemies.enqueue("spacemig", (-1,10), (483,-70), 94)
	enemies.enqueue("ballzep", (1,3), (120,-226), 100)
	enemies.enqueue("ballzep", (-1,3), (425,-226), 100)

	#Engage Stalin

	#enemies.create("attacksat",  (1,1), (300, 300))
	
	try:
		IsFire1Down = 0
		IsFire2Down = 0
		IsFire3Down = 0
		bulletframe = globals.BULLETDELAY
		missileframe = globals.MISSILEDELAY
		bombframe = globals.BOMBDELAY
		while globals.GOTOSCREEN == "Mission 3":
			clock.tick(globals.FRAMESPERSECOND)
			events = pygame.event.get()
			for event in events:
					if event.type == pygame.KEYDOWN:
							if event.key == pygame.K_ESCAPE:
									globals.GOTOSCREEN = "Title Screen"
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_1:
									IsFire1Down = 1
							if event.key == pygame.K_2:
									IsFire2Down = 1
							if event.key == pygame.K_3:
									IsFire3Down = 1
							if event.key == pygame.K_m:
								SoundEngine.SetEffectVolume (0.0)
								SoundEngine.SetMusicVolume (0.0)
							if event.key == pygame.K_n:
								SoundEngine.SetEffectVolume (0.3)
								SoundEngine.SetMusicVolume (0.9)
							
							if globals.DEBUG == True:
								if event.key == pygame.K_h: #extra lives hack
									PlayerShip.lives = PlayerShip.lives + 1
								if event.key == pygame.K_i: #sort of temporary invincibility hack....
									PlayerShip.state = globals.PLAYER_REVIVING
								if event.key == pygame.K_o: #force level over hack
									enemies.queue = []
									for b in enemies.hostile_list:
										enemies.hostile_list.remove(b)
								if event.key == pygame.K_u: #blow up the player's ship
									PlayerShip.die()
										
					elif event.type == pygame.KEYUP:
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 0
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 0
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 0
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 0
							if event.key == pygame.K_1:
									IsFire1Down = 0
							if event.key == pygame.K_2:
									IsFire2Down = 0
							if event.key == pygame.K_3:
									IsFire3Down = 0

			if IsFire1Down == 1 and bulletframe > globals.BULLETDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBullet = BulletTemplate((275,600))
					
					newBullet.rect.center = PlayerShip.rect.center
					newBullet.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBullet.vertvel = 0
					else:
							newBullet.vertvel = PlayerShip.vertvel
					newBullet.horizvel = PlayerShip.horizvel
					projectile_list.append(newBullet)
					bulletframe = 0
					
			elif IsFire2Down == 1 and missileframe > globals.MISSILEDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newMissile = MissileTemplate((275,600))
					newMissile.rect.center = PlayerShip.rect.center
					newMissile.rect.move_ip(8,-3)
					if PlayerShip.vertvel > 0:
							newMissile.vertvel = 0
					else:
							newMissile.vertvel = PlayerShip.vertvel
					projectile_list.append(newMissile)
					missileframe = 0
					
			elif IsFire3Down == 1 and bombframe > globals.BOMBDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBomb = BombTemplate(globals.ARTDIR + "EMP.png", (400,400))
					newBomb.rect.center = PlayerShip.rect.center
					newBomb.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBomb.vertvel = 0
					else:
							newBomb.vertvel = PlayerShip.vertvel
					
					enemies.empbomb(projectile_list)
					del projectile_list
					projectile_list = []
					projectile_list.append(newBomb)
					
					bombframe = 0
			
			PlayerShip.update()

			for projectile in projectile_list[:]:
				if projectile.rect.bottom < 0 or projectile.rect.top > 800 or projectile.rect.left < 0 or projectile.rect.right > 600:
					projectile_list.remove(projectile)
				elif projectile.used == 1:
					projectile_list.remove(projectile)
				else:
					projectile.update(projectile_list, PlayerShip)
				
			
			# do the drawing
			screen.fill((0,0,0))
			
			background.draw()
			
			
			enemies.draw(projectile_list, PlayerShip)

			#render manager code will go here
			
			for projectile in projectile_list[:]:
					screen.blit(projectile.image, projectile.rect, pygame.Rect(projectile.leftoffset,projectile.topoffset,projectile.rect.width,projectile.rect.height))
					#check for hits on the player
					if projectile.hostile == 1 and PlayerShip.state == globals.PLAYER_NORMAL and projectile.rect.colliderect(PlayerShip.rect):
						PlayerShip.hit(projectile.damage)
						projectile_list.remove(projectile)


			screen.blit(PlayerShip.image, PlayerShip.rect, pygame.Rect(PlayerShip.leftpadding,0,PlayerShip.width,PlayerShip.height))
						
			hud.draw(PlayerShip, bombframe)
			

			bulletframe += 1
			missileframe += 1
			bombframe += 1
			pygame.display.update()
			SoundEngine.Update()
		
                goto_handler(globals.GOTOSCREEN)
	
	except:
		print pygame.error()







		
		
		
		
def mission_stalin():
	SoundEngine.FadeToBgMusic (globals.SOUNDMUSICDIR + "music_1.ogg")
	projectile_list = []
	
	PlayerShip = ShipTemplate(globals.STAGE_3, (275,600))
	background = Background(globals.STAGE_STALIN)
	
	globals.TRANSIT = False
	globals.ISSHIPINTRANSIT= 0
	globals.GOTOSCREEN = "Mission Stalin"
	
	enemies = Hostiles()
	
	hud.reset()
	hud.enqueueSound ("laugh", 1.0)
	

	# mission control
	enemies.create("stalin",  (1,1), (275, 150))
	
	
	try:
		IsFire1Down = 0
		IsFire2Down = 0
		IsFire3Down = 0
		bulletframe = globals.BULLETDELAY
		missileframe = globals.MISSILEDELAY
		bombframe = globals.BOMBDELAY
		while globals.GOTOSCREEN == "Mission Stalin":
			clock.tick(globals.FRAMESPERSECOND)
			events = pygame.event.get()
			for event in events:
					if event.type == pygame.KEYDOWN:
							if event.key == pygame.K_ESCAPE:
									globals.GOTOSCREEN = "Title Screen"
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 1
									GlobalSounds.PlayEffectById ("thruster")
							if event.key == pygame.K_1:
									IsFire1Down = 1
							if event.key == pygame.K_2:
									IsFire2Down = 1
							if event.key == pygame.K_3:
									IsFire3Down = 1
							if event.key == pygame.K_m:
								SoundEngine.SetEffectVolume (0.0)
								SoundEngine.SetMusicVolume (0.0)
							if event.key == pygame.K_n:
								SoundEngine.SetEffectVolume (0.3)
								SoundEngine.SetMusicVolume (0.9)
							
							if globals.DEBUG == True:
								if event.key == pygame.K_h: #extra lives hack
									PlayerShip.lives = PlayerShip.lives + 1
								if event.key == pygame.K_i: #sort of temporary invincibility hack....
									PlayerShip.state = globals.PLAYER_REVIVING
								if event.key == pygame.K_o: #force level over hack
									enemies.queue = []
									for b in enemies.hostile_list:
										enemies.hostile_list.remove(b)
								if event.key == pygame.K_u: #blow up the player's ship
									PlayerShip.die()
										
					elif event.type == pygame.KEYUP:
							if event.key == pygame.K_UP:
									PlayerShip.goingup = 0
							if event.key == pygame.K_DOWN:
									PlayerShip.goingdown = 0
							if event.key == pygame.K_LEFT:
									PlayerShip.goingleft = 0
							if event.key == pygame.K_RIGHT:
									PlayerShip.goingright = 0
							if event.key == pygame.K_1:
									IsFire1Down = 0
							if event.key == pygame.K_2:
									IsFire2Down = 0
							if event.key == pygame.K_3:
									IsFire3Down = 0

			if IsFire1Down == 1 and bulletframe > globals.BULLETDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBullet = BulletTemplate((275,600))
					
					newBullet.rect.center = PlayerShip.rect.center
					newBullet.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBullet.vertvel = 0
					else:
							newBullet.vertvel = PlayerShip.vertvel
					newBullet.horizvel = PlayerShip.horizvel
					projectile_list.append(newBullet)
					bulletframe = 0
					
			elif IsFire2Down == 1 and missileframe > globals.MISSILEDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newMissile = MissileTemplate((275,600))
					newMissile.rect.center = PlayerShip.rect.center
					newMissile.rect.move_ip(8,-3)
					if PlayerShip.vertvel > 0:
							newMissile.vertvel = 0
					else:
							newMissile.vertvel = PlayerShip.vertvel
					projectile_list.append(newMissile)
					missileframe = 0
					
			elif IsFire3Down == 1 and bombframe > globals.BOMBDELAY and (PlayerShip.state == globals.PLAYER_NORMAL or PlayerShip.state == globals.PLAYER_REVIVING):
					newBomb = BombTemplate(globals.ARTDIR + "EMP.png", (400,400))
					newBomb.rect.center = PlayerShip.rect.center
					newBomb.rect.move_ip(18,-3)
					if PlayerShip.vertvel > 0:
							newBomb.vertvel = 0
					else:
							newBomb.vertvel = PlayerShip.vertvel
					
					enemies.empbomb(projectile_list)
					
					del projectile_list
					projectile_list = []
					projectile_list.append(newBomb)
					
					bombframe = 0
			
			PlayerShip.update()

			for projectile in projectile_list[:]:
				if projectile.rect.bottom < 0 or projectile.rect.top > 800 or projectile.rect.left < 0 or projectile.rect.right > 600:
					projectile_list.remove(projectile)
				elif projectile.used == 1:
					projectile_list.remove(projectile)
				else:
					projectile.update(projectile_list, PlayerShip)
				
			
			# do the drawing
			screen.fill((0,0,0))
			
			background.draw()
			
			
			enemies.draw(projectile_list, PlayerShip)
			
			
			#render manager code will go here
			
			for projectile in projectile_list[:]:
					screen.blit(projectile.image, projectile.rect, pygame.Rect(projectile.leftoffset,projectile.topoffset,projectile.rect.width,projectile.rect.height))
					#check for hits on the player
					if projectile.hostile == 1 and PlayerShip.state == globals.PLAYER_NORMAL and projectile.rect.colliderect(PlayerShip.rect):
						PlayerShip.hit(projectile.damage)
						projectile_list.remove(projectile)


			screen.blit(PlayerShip.image, PlayerShip.rect, pygame.Rect(PlayerShip.leftpadding,0,PlayerShip.width,PlayerShip.height))
						
			hud.draw(PlayerShip, bombframe)
			

			bulletframe += 1
			missileframe += 1
			bombframe += 1
			pygame.display.update()
			SoundEngine.Update()
		
                goto_handler(globals.GOTOSCREEN)
	
	except:
		print pygame.error()
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
goto_handler(globals.GOTOSCREEN)
