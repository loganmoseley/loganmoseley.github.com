# Team 2 Sound Engine
# to use: from Sound import SoundEngine

# load stuff and start the mixer if not running as main
if __name__ != "__main__":
	import pygame
	import os
	import globals
	# start the mixer
	if pygame.mixer.get_init():
		pygame.mixer.quit()
	pygame.mixer.pre_init(globals.SOUNDFREQUENCY, globals.SOUNDSAMPLESIZE, globals.SOUNDSTEREO, globals.SOUNDBUFFERSIZE)
	pygame.mixer.init ()
# load stuff differently if the main
else:	
	# load imports and screen
	import os
	import globals
	import pygame

# a single effect
class Effect:
	def __init__ (self, file):
		self.file = file
		self.loop = False
		try:
			self.effect = pygame.mixer.Sound (self.file)
		except:
			pass

# the sound effects class
	# used as an interface for an individual object that wants to play sounds
class SoundEffects:
	def __init__ (self, engine):
		self.effects = {}
		self.engine = engine
	
	# add a sound file
	def AddEffect (self, file, id):
		index = -1
		try:
			index = self.engine.AddEffect (file)
		except:
			return -1
		try:	
			if index >= 0:
				self.effects[id] = index
				return id
			else:
				return -1
		except:
			return -1
	
	# play an effect by id
	def PlayEffectById (self, id):
		try:
			return self.engine.PlayEffectById (self.effects[id], 0)
		except:
			return -1
	
	# stop an effect by id
	def StopEffectById (self, id):
		try:
			return self.engine.StopEffectById (self.effects[id])
		except:
			retunr -1
	
	# play an effect by file name
	def PlayEffectByFile (self, file):
		return self.engine.PlayEffectByFile (file)
	
	# stop an effect by file name
	def StopEffectByFile (self, file):
		return self.engine.StopEffectByFile (file)
		
	# begin looping an effect
	def LoopEffectById (self, id):
		try:
			return self.engine.PlayEffectById (self.effects[id], -1)
		except:
			return -1

class Engine:
	# initialize the sound engine
	def __init__ (self):
		# vars needed to make things go
		self.effects = []
		self.playing_effects = {}

		# vars for external access
		self.ERRSTR = ""		# error string - the most recent error
		self.WARNSTR = ""		# warning string - the most recent warning
		
		# main music vars
		self.last_played = ""
		self.fade_to_file = ""
		
		# load sounds in the defauld sound dir
		try:
			dir = os.listdir (globals.SOUNDEFFECTSDIR)
		except:
			dir = []
		for file in dir:
			file_parts = file.split ('.')
			extension = file_parts.pop()
			if (extension == "wav" or extension == "ogg"):
				try:
					self.AddEffect (globals.SOUNDEFFECTSDIR + file)
				except:
					continue

	# add an effect to the general self.effects store
	def AddEffect (self, file):
		for i in range (len (self.effects)):
			if self.effects[i].file == file:
				return i
		try:
			effect = Effect (file)
		except:
			self.ERRSTR = "Failed to load the sound file."
			return -1
		try:
			effect.effect.set_volume (globals.SOUNDEFFECTSVOLUME)
		except:
			self.WARNSTR = "Failed to set the effect volume."
		self.effects.append (effect)
		return len (self.effects) - 1

	# play an effect by id
	def PlayEffectById (self, id, loop):
		if id < len (self.effects) and id > -1:
			try:
				self.effects[id].effect.play (loop)
			except:
				self.ERRSTR = "Failed to play the sound effect."
				return -1
			if loop == -1:
				self.effects[id].loop = True
			#self.playing_effects[id] = self.effects[id]
		else:
			self.ERRSTR = "Effect id is not valid."
			return -1
		return 0

	# stop an effect by id
	def StopEffectById (self, id):
		if id < len (self.effects) and id > -1:
			try:
				self.effects[id].effect.stop ()
				self.effects[id].loop = False
			except:
				self.ERRSTR = "Failed to stop the sound effect."
				return -1
		else:
			self.ERRSTR = "Effect id is not valid."
		return 0

	# play an effect by file
	def PlayEffectByFile (self, file):
		return self.PlayEffectById (self.AddEffect (file), 0)

	# stop an effect by file
	def StopEffectByFile (self, file):
		return self.StopEffectById (self.AddEffect (file))

	# begin to play a specific track as the background music
	def PlayBgMusic (self, file):
		try:
			pygame.mixer.music.load (file)
		except:
			self.ERRSTR = "Pygame failed to load the music file."
			return -1
		try:
			pygame.mixer.music.set_volume (globals.SOUNDMUSICVOLUME)
		except:
			self.WARNSTR = "Pygame failed to set the mixer volume."
		try:
			pygame.mixer.music.play ()
		except:
			self.ERRSTR = "Pygame failed to begin playing the music."
			return -1
		self.last_played = file
		return 0

	# stop currently playing bbackground music
	def StopBgMusic (self):
		self.fade_to_file = ""
		try:
			pygame.mixer.music.stop ()
		except:
			self.ERRSTR = "Pygame failed to stop the playing music."
			return -1
		return 0
	
	# fade out the bg music
	def FadeBgMusic (self):
		self.fade_to_file = ""
		try:
			pygame.mixer.music.fadeout (globals.SOUNDMUSICFADETIME)
		except:
			return -1
		return 0
		
	# fade out the music then play a specific song
	def FadeToBgMusic (self, file):
		self.fade_to_file = file
		return self.FadeBgMusic ()

	# queue a track to play as background music
	def QueueBgMusic (self, file):
		try:
			pygame.mixer.music.queue (file)
		except:
			self.ERRSTR = "pygame failed to queue the music file."
			return -1
		return 0

	# fade out the current music
	def FadeBgMusic (self):
		if pygame.mixer.music.get_busy():
			try:
				pygame.mixer.music.fadeout (globals.SOUNDMUSICFADETIME)
			except:
				self.ERRSTR = "Pygame could not begin the music fadeout."
				return -1
		return 0

	# pause the current music
	def PauseBgMusic (self):
		try:
			pygame.mixer.music.pause ()
		except:
			self.ERRSTR = "Pygame could not pause the music."
			return -1
		return 0

	# resume the current music
	def ResumeBgMusic (self):
		try:
			pygame.mixer.music.unpause ()
		except:
			self.ERRSTR = "Pygame could not resume the music."
			return -1
		return 0

	# change the volume for sound self.effects
	def SetEffectVolume (self, vol):
		ret_val = 0
		if vol <= 1 and vol >= 0:
			globals.SOUNDEFFECTSVOLUME = vol
			for effect in self.effects:
				try:
					effect.effect.set_volume (globals.SOUNDEFFECTSVOLUME)
				except:
					self.WARNSTR = "Could not change the effect volume."
					ret_val = ret_val +1
			return ret_val
		else:
			self.ERRSTR = "Incorrect volume parameter."
			return -1

	# change the volume fot the music
	def SetMusicVolume (self, vol):
		if vol <= 1 and vol >= 0:
			globals.SOUNDMUSICVOLUME = vol
			try:
				pygame.mixer.music.set_volume (globals.SOUNDMUSICVOLUME)
			except:
				self.WARNSTR = "Pygame could not change the currently playing music volume."
				return 1
			return 0
		else:
			self.ERRSTR = "Incorrect volume parameter."
			return -1
	
	# create a sound effect list for this engine
	def EffectList (self):
		return SoundEffects (self)
	
	# update the currently playing sounds - must be called with each frame
	def Update (self):
		ret_val = 0
		if not pygame.mixer.music.get_busy ():
			if self.fade_to_file != "":
				ret_val = ret_val + self.PlayBgMusic (self.fade_to_file)
			elif self.last_played != "":
				ret_val = ret_val + self.PlayBgMusic (self.last_played)
		return ret_val

SoundEngine = Engine()

# test the sound module
def Test ():
	print "Testing Sound Module..."
	pygame.init()
	screen = pygame.display.set_mode ((600, 100))
	
	# start the mixer
	print "Mixer settings..."
	print globals.SOUNDFREQUENCY
	print globals.SOUNDSAMPLESIZE
	print globals.SOUNDSTEREO
	print globals.SOUNDBUFFERSIZE
	print "Initializing mixer..."
	if pygame.mixer.get_init():
		print  "\tMixer already running, stopping it..."
		pygame.mixer.quit()
	print "\tStarting mixer..."
	pygame.mixer.init (globals.SOUNDFREQUENCY, globals.SOUNDSAMPLESIZE, globals.SOUNDSTEREO, globals.SOUNDBUFFERSIZE)

	# set up testing vars
	print "Setting up test files..."
	files = []
	
	files.append ("../sound/laugh.wav")
	files.append ("../sound/sound101.wav")
	files.append ("../sound/sound102.wav")

	# make a sound effect
	effects = SoundEngine.EffectList()
	print effects

	print "Testing for each file..."
	num = 0
	for file in files:
		print effects.AddEffect (file, num)
		print effects.PlayEffectById (num)
		print effects.PlayEffectByFile (file)
		num = num + 1
		
	print "Testing background music..."
	file = "../sound/knightrider.mp3"
	SoundEngine.PlayBgMusic (file)

	pygame.time.wait (5000)			
	print "Done Testing."
	
# if main execution run testing
if __name__ == "__main__":
	# begin testing
	print "Loaded as __main__:"
	Test ()
